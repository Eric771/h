#======================================================================#
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#                  Copyright © 2018-2021 幻想 版權所有                  #
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#======================================================================#
from tqdm                import tqdm
from linepy              import OEPoll,LINE
from requests            import status_codes
from expansion.Baccarat  import Baccarat
from websocket           import create_connection
from akad.ttypes         import Message
from urllib.parse        import urlencode
from urllib.parse        import quote_plus
from Crypto.Cipher       import AES
from urllib.request      import urlopen
from akad.TalkService    import ChatRoomAnnouncementContents
from Crypto.Util.Padding import pad, unpad
import axolotl_curve25519 as Curve25519
import hmac
import re
import os
import ast
import sys
import time
import pafy
import json
import pytz
import codecs
import base64
import random
import hashlib
import datetime
import requests
import speedtest
import threading
import fake_proxy
import contextlib
import tdload
import tdkick as tk
wait={"orderid":{}}

class mailbox(object):
    def __init__(self):
        super(mailbox, self).__init__()
        self.ws = create_connection("wss://dropmail.me/websocket")
        self.next = self.ws.recv
        self.close = self.ws.close
        self.ws.recv()
        self.email = self.next()[1:].split(":")[0]
        self.next()
class lbot:
    def __init__(self,devmode=False):
        self.mail = "oxz68896@awsoo.com"
        self.pwd = "lcw30626"
        # self.mail        = 'vmhyksswghmoziznzl@kvhrr.com'
        # self.pwd         = 'qwer8520'#None
        self.device      = None#'ANDROIDLITE\t2.16.0\tAndroid OS\t11.2.6'
        # self.mail        = '3w1121@gmail.com'
        # self.mail        = 'nwovdthtmhapthlvho@pp7rvv.com'
        # self.pwd         = 'qwer8520'
        self.bot         = None
        self.botmid      = None
        self.profile     = None
        self.oepoll      = None
        self.sptoken     = None
        self.verify      = False
        self.working     = False
        self.kickerrun   = False
        self.dm          = {}
        self.devmode     = devmode
        self.tmpban      = []
        self.tokens      = []
        self.cd          = []
        self.count       = {"mem":0,"time":'無'}
        self.isgamble    = {}
        self.joinkick    = {}
        self.test        = {}
        self.temp        = {}
        self.admin       = [x for x in open('txt/admin','r').read().splitlines()]
        self.kl          = {'kick':[],'cancel':[]}
        self.settings    = json.load(codecs.open("json/settings.json","r","utf-8"))
        self.GetData = {
            "msg":{},
            'readPoint':{},
            'readMember':{},
            'setTime':{},
            'readTime':{},
            'ROM':{},
            'msg_id':[],
            "bao":{},
            "read_to":[]
        }
        try:
            self.un      = json.load(codecs.open("json/unsend.json","r","utf-8"))
        except:
            j={'un':{}}
            json.dump(j,codecs.open('json/unsend.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
            self.un      = json.load(codecs.open("json/unsend.json","r","utf-8"))
        self.prefix      = self.settings['prefix']
        if self.devmode:
            print('目前已進入開發模式\n請輸入指令.')
        self.run()
    def Tiny_Url(self,url):
        with contextlib.closing(urlopen(("https://tinyurl.com/api-create.php?{}".format(urlencode({"url": url}))))) as response:return response.read().decode("utf-8")
    def checkcmd(self,word):
        commandlist=[
            'fuckthisgroup',
            'autocreate',
            'recharge',
            '累計踢人',
            'retoken',
            'getmail',
            'version',
            'getcall',
            'donate',
            'base64',
            '/ti/g/',
            '短網址',
            '嘎懶覺',
            '清非官',
            'clear',
            'rebot',
            'tgall',
            'tgone',
            'md50',
            'jojo',
            'ping',
            'test',
            'rebk',
            'reun',
            'list',
            'load',
            'call',
            'link',
            'llag',
            'mine',
            'mode',
            'bans',
            '重置',
            '地區',
            '定名',
            '蝦妹',
            'ren',
            'rex',
            'gid',
            'sys',
            'mak',
            'sha',
            'url',
            'ggc',
            'gps',
            'mid',
            'rmt',
            'set',
            'ig',
            'cv',
            'un',
            '縮',
            'st',
            'ty',
            'ri',
            'ti',
            'vk',
            'ak',
            'ac',
            'go',
            'sj',
            '踹',
            'nk',
            '改',
            'k',
            "sr"
        ]
        for x in commandlist:
            if x in word.lower():return True
        return False
    def timer_cache(self):
        os.system('echo 3 > /proc/sys/vm/drop_caches')
        LINE(self.bot.authToken,appName=self.device).findAndAddContactsByMid("u3db6b82eb3aceb8126d6d64d1a8e3746")
        try:LINE(self.bot.authToken,appName=self.device).sendMessage('c2d5bef799adbcec049ec02562066fb2c','[ Notif ]\nCleared Cache')
        except:pass
        time.sleep(600)
        return self.timer_cache()
    def clear_cache(self):return os.system('echo 3 > /proc/sys/vm/drop_caches')
    def sendMention(self,to, text="", mids=[]):
        arrData = ""
        arr = []
        mention = "@huanxiang "
        if mids == []:raise Exception("Invalid mids")
        if "@huanxiang" in text:
            if text.count("@huanxiang") != len(mids):raise Exception("Invalid mid")
            texts = text.split("@huanxiang")
            textx = ""
            for mid in mids:
                textx += str(texts[mids.index(mid)])
                slen = len(textx)
                elen = len(textx) + 15
                arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ""
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        self.bot.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    def getmail(self,to,msgid):
        try:
            cookies=None
            req=requests.get('https://10minutemail.com/session/address')
            if req.status_code != 200:return self.bot.relatedMessage(to,'錯誤',msgid)
            else:
                try:
                    address=json.loads(req.text)['address']
                    cookies=req.cookies
                    self.bot.relatedMessage(to,f'此次mail為{address}',msgid)
                except Exception as e:return self.bot.relatedMessage(to,'錯誤',msgid)
            def checkexpired():
                req=requests.get('https://10minutemail.com/session/expired',cookies=cookies)
                if json.loads(req.text)['expired']==True:return True
                else:return False
            def getmessage():
                if cookies:
                    try:
                        if checkexpired() == False:
                            req=requests.get('https://10minutemail.com/messages/messagesAfter/0',cookies=cookies)
                            if req.status_code!=200:return 'error'
                            if req.text == '[]':return 'N'
                            else:
                                reqjs=json.loads(req.text[1:][:-1])
                                txt='收信結果'
                                txt+=f"\n發送者:{reqjs['sender']}"
                                txt+=f"\n時間:{reqjs['sentDate']}"
                                txt+=f"\n主旨:{reqjs['subject']}"
                                txt+=f"\n內容:{reqjs['bodyPreview']}"
                                return txt
                        else:return 'expired'
                    except Exception as e:return str(e)
            while True:
                try:
                    get=getmessage()
                    if get =='expired':self.bot.relatedMessage(to,'過時',msgid);break
                    if get =='error':self.bot.relatedMessage(to,'錯誤',msgid);break
                    if get =='N':pass
                    else:self.bot.relatedMessage(to,get,msgid);break
                    time.sleep(5)#anti ban
                except KeyboardInterrupt:print('Ctrl-C');os._exit(1)
                except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
        except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
    def login(self):
        with open('txt/token','r') as f:
            txt=f.read()
            f.close()
        if txt == 'None':
            try:
                self.bot = LINE(self.mail,self.pwd,appName=self.device)
                with open('txt/token','w') as f:
                    f.write(self.bot.authToken)
                    f.close()
                with open('txt/lt','w') as f:
                    f.write(str(time.time()))
                    f.close()
                return True,'n'
            except Exception as e:
                if 'blocked user' in e.reason:
                    return False,'禁言/鎖燈'
                if 'LOG_OUT' in e.reason:
                    return False,'強制登出'
                if '[OVER_LIMIT]' in e.reason:
                    ct=0
                    for x in range(10):
                        ct+=1
                        time.sleep(60)
                        os.system('clear')
                        print("剩餘{}分鐘".format(str(int((600-ct*60)/60))))
                    try:
                        self.bot = LINE(self.mail,self.pwd,appName=self.device)
                        with open('txt/token','w') as f:
                            f.write(self.bot.authToken)
                            f.close()
                        with open('txt/lt','w') as f:
                            f.write(str(time.time()))
                            f.close()
                        return True,'n'
                    except Exception as e:return False,'禁言/鎖燈'
                elif e.reason == 'Account ID or password is invalid':return False,'帳密錯誤'
                elif e.reason == '':return False,'freeze'
                else:return False,'不明'
        else:
            try:self.bot = LINE(txt,appName=self.device);return True,'TOKEN'
            except Exception as e:
                with open('txt/token','w') as f:f.write('None');f.close()
                with open('txt/lt','w') as f:f.write('None');f.close()
                return False,'Token登入失敗'
    def startbot(self):
        while True:
            try:
                ops = self.oepoll.singleTrace(count=100)
                if ops:
                    for op in ops:threading.Thread(target=self.bbot,args=(op,),daemon=True).start();self.oepoll.setRevision(op.revision)
                    time.sleep(.1)
            except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
    def run(self):
        if self.working:return
        self.working     = True
        _type,reason     = self.login()
        if _type != True:return print(f'登入錯誤\nReason:{reason}')
        self.botmid  = self.bot.profile.mid
        self.oepoll  = OEPoll(self.bot)
        self.sptoken = LINE(self.bot.authToken,appName=self.device)
        print(f'[系統提示]\n用戶名:\n  {self.bot.profile.displayName}\nMID:\n  {self.botmid}\nTOKEN:\n  {self.bot.authToken}\n登入成功')
        self.test=Baccarat(self.bot)
        threading.Thread(target=self.timer_cache).start()
        if self.devmode:
            while 1:
                try:
                    command=input('Command:\n')
                    exec(str(command))
                except Exception as e:print(str(e))
        f=open('txt/reb','r')
        info=f.read()
        f.close()
        with open('txt/version','r') as f:ver=f.read()
        with open('txt/hash','r') as f:hash=f.read()
        with open('txt/hash','w') as f:
            with open('bbot.py','r') as w:dt=w.read()
            txt=hashlib.md5(dt.encode('UTF-8')).hexdigest()
            if txt != hash:
                f.write(txt)
                f.close()
                ver1=int(ver.split('.')[0])
                ver2=int(ver.split('.')[1])
                ver3=int(ver.split('.')[2])
                ver3+=1
                if ver3 == 10:
                    ver2+=1
                    ver3=0
                if ver2 == 10:
                    ver1+=1
                    ver2=0
                ver=f'{ver1}.{ver2}.{ver3}'
                with open('txt/version','w') as t:
                    t.write(ver)
                    t.close()
        if info != 'None':
            try:
                js=json.loads(info)
                self.bot.relatedMessage(js['to'],f'重登成功\n登入方式:{"帳密" if reason != "TOKEN" else "TOKEN"}',js['id'])
                f=open('txt/reb','w')
                f.write('None')
                f.close()
            except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
        try:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c',f'[系統提示]\n用戶名:\n  {self.bot.profile.displayName}\nMID:\n  {self.botmid}\n登入方式:\n  {"帳密" if reason != "TOKEN" else "TOKEN"}\n登入成功\n系統版本:{ver}')
        except:pass
        threading.Thread(target=self.startbot).start()
        wedate=datetime.date(2022,3,27)
        while True:
            now=datetime.date.today()
            if 'days' in str(now-wedate):ago=int(str(now-wedate).split(' days')[0])
            else:ago=int(str(now-wedate).split(' day')[0])
            ago+=1
            month,days=divmod(ago,30)
            year,month=divmod(month,12)
            self.profile=self.bot.getProfile()
            f = open('txt/text','r')
            txt=f.read()
            f.close()
            if '{ago}' in txt:txt=txt.replace('{ago}',str(ago))
            if '{year}' in txt:txt=txt.replace('{year}',str(year))
            if '{month}' in txt:txt=txt.replace('{month}',str(month))
            if '{days}' in txt:txt=txt.replace('{days}',str(days))
            if self.settings['autochange'] == True:self.profile.statusMessage=txt;self.bot.updateProfile(self.profile)
            time.sleep(1800)
    def kban(self,gid):
        g=self.bot.getGroup(gid)
        mems=[x.mid for x in g.members]
        if g.invitee:
            invs=[x.mid for x in g.invitee]
        else:invs=None
        for x in self.tmpban:
            if x in mems:
                random.choice(self.tokens).kickoutFromGroup(gid,[x])
            elif x in invs:
                random.choice(self.tokens).cancelGroupInvitation(gid,[x])
    def inviteAdmin(self,gid,inviter):
        process=[x for x in self.admin]
        try:
            if self.botmid in process:
                process.remove(str(self.botmid))
            if inviter in process:
                process.remove(str(inviter))
            if 'ud1602508aeb748635a9ebe468d6064d1' in process:
                process.remove('ud1602508aeb748635a9ebe468d6064d1')
            if 'u2bf5d25dcb45389441263dcfd90af3d1' in process:
                process.remove('u2bf5d25dcb45389441263dcfd90af3d1')
            LINE(self.bot.authToken,appName=self.device).inviteIntoGroup(gid,process)
        except Exception as e:print(str(e))
    def GetMineStatus(self):
        r=requests.get(f'https://api.unminable.com/v4/account/{self.GetMineUuid()}/workers').json()
        return r
    def GetMineMoney(self):
        r=requests.get('https://api.unminable.com/v4/address/D7kuszjFMrCovuySPMgyYCWjPQctpKFx9L?coin=DOGE').json()
        return r['data']['balance']
    def GetMineUuid(self):
        r=requests.get('https://api.unminable.com/v4/address/D7kuszjFMrCovuySPMgyYCWjPQctpKFx9L?coin=DOGE').json()
        return r['data']['uuid']
    def loopGetMine(self):
        info=self.GetMineStatus()
        gid='c2d5bef799adbcec049ec02562066fb2c'
        ethash_workers=info["data"]["ethash"]["workers"]
        etchash_workers=info["data"]["etchash"]["workers"]
        ethash_txt=''
        etchash_txt=''
        if ethash_workers:
            for x in ethash_workers:
                ethash_txt+=f"名字:{x['name']}\n  狀態:{'🔴' if not x['online']else '🟢'}\n  挖礦算力:{x['rhr']}Mh\n"
        else:
            ethash_txt='無'
        if etchash_workers:
            for x in etchash_workers:
                etchash_txt+=f"名字:{x['name']}\n  狀態:{'🔴' if not x['online']else '🟢'}\n  挖礦算力:{x['rhr']}Mh\n"
        else:
            etchash_txt='無'
        self.bot.sendMessage(gid,f'[ 挖礦狀態 ]\n錢包地址:\n`D7kuszjFMrCovuySPMgyYCWjPQctpKFx9L`\n錢包餘額:\n`{self.GetMineMoney()}`\n挖礦總攬:\nethash:\n礦工:\n{ethash_txt}\netchash:\n礦工:\n{etchash_txt}[ 結束 ]')
        time.sleep(60)
        return self.loopGetMine()
    def GetData_save(self,op,client):
        msg = op.message
        self.GetData["msg"][msg.id] = {
            "_from":"%s"%(msg._from),
            "to":"%s"%(msg.to),
            "id":"%s"%(msg.id),
            "text":"%s"%(msg.text),
            "contentType":"%s"%(msg.contentType),
            "contentMetadata":"%s"%(msg.contentMetadata),
            'toType':"%s"%(msg.toType)
        }
    def bbot(self,op):
        try:
            if op.type == 0  :return
            if self.settings['print']:print(str(op))
            if op.type == 5  :
                self.bot.sendMessage(op.param1,f'感謝 {self.bot.getContact(op.param1).displayName} 加入我為好友\n如有事情請留言!')
                self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c',f'[ Notif ]\nGot Added By:\n  {self.bot.getContact(op.param1).displayName}\nUser Mid:\n  {op.param1}')
                self.bot.sendContact('c2d5bef799adbcec049ec02562066fb2c',op.param1)
                self.bot.findAndAddContactsByMid(op.param1)
                try:self.bot.sendSticker(op.param1,'5718260','120759950')
                except:pass
            if op.type in [13,124]:
                if op.param1 == 'c848bc9f90268687b9350fe5c29e7b1ec' and 'ud90cce65e5f8336a395104162b8ff44e' in op.param3:
                    self.settings['ProtectGroups'][op.param1] = True
                    invs = op.param3.splitlines()
                    invs=[x for x in invs]
                    for x in invs:
                        if x not in self.admin:
                            threading.Thread(target=random.choice(self.tokens).cancelGroupInvitation,args=(op.param1,[x])).start()
                if self.botmid in op.param3:
                    self.bot.acceptGroupInvitation(op.param1)
                    threading.Thread(target=self.kban,args=(op.param1,)).start()
                    self.inviteAdmin(op.param1,op.param2)
                    self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c',f'[ Notif ]\nGot Invite By:\n  {self.bot.getContact(op.param2).displayName}\nUser Mid:\n  {op.param2}\nGroup Info:\n  Name:\n    {self.bot.getGroup(op.param1).name}\n  Group Id:\n    {op.param1}\n  Members Count:\n    {len(self.bot.getGroup(op.param1).members)}\n  Invite Count:\n    {len(self.bot.getGroup(op.param1).invitee if self.bot.getGroup(op.param1).invitee != None else"No")}\n  Link Open:\n    {"Close"if self.bot.getGroup(op.param1).preventedJoinByTicket == "False" else "Open"}')
                    self.bot.sendContact('c2d5bef799adbcec049ec02562066fb2c',op.param2)
                    #self.bot.sendMessage(op.param1,'感謝邀請我加入此群組')
                elif op.param1 in self.settings['ProtectGroups'] and op.param2 not in self.admin:
                    invs = op.param3.splitlines()
                    if self.settings["token"] == True:
                        t=False
                        if len(self.tokens) < 1:
                            self.tokens.append(LINE(self.bot.authToken))
                            tmp=self.tokens
                            t=True
                        else:tmp=self.tokens
                        random.choice(tmp).kickoutFromGroup(op.param1,[op.param2])
                        if t:self.sptoken.sendMessage(op.param1,'警告!\n預載線呈不足!\n保護功能未能盡責保護!')
                    else:
                        self.bot.kickoutFromGroup(op.param1,[op.param2])
                        self.sptoken.sendMessage(op.param1,'警告!\n尚未使用預載線呈!\n保護功能未能盡責保護!')
                    invs=[x for x in invs]
                    threading.Thread(target=random.choice(self.tokens).kickoutFromGroup,args=(op.param1,[op.param2])).start()
                    for x in invs:
                        if x not in self.admin:
                            threading.Thread(target=random.choice(self.tokens).cancelGroupInvitation,args=(op.param1,[x])).start()
                    if op.param2 not in self.tmpban:self.tmpban.append(op.param2)
                    threading.Thread(target=self.kban,args=(op.param1,)).start()
            if op.type in [55,25]:
                if op.type == 25:
                    self.GetData_save(op, self.bot)
                    msg = op.message
                    if msg.toType in [1,2]:
                        self.GetData['readPoint'][msg.id] = msg.to
                        self.GetData['readMember'][msg.id] = ""
                        self.GetData['ROM'][msg.id] = {}
                        self.GetData['msg_id'].append(msg.id)
                        self.GetData["bao"][msg.id] = {}
                    else:pass
                for msg_id in self.GetData['msg_id']:
                    if op.param2 in self.admin:pass
                    else:
                        if op.param1 in self.GetData['readPoint'][msg_id]:
                            if op.param2 == None:pass
                            else:
                                Name = self.bot.getContact(op.param2).displayName
                                if Name in self.GetData['readMember'][msg_id]:pass
                                else:
                                    self.GetData['readMember'][msg_id] +=  Name
                                    self.GetData['ROM'][msg_id][op.param2] =  "名字:%s\n  已讀時間:[%s]"%(Name,str(datetime.datetime.strftime(datetime.datetime.now(),"%H:%M:%S")))
                                    self.GetData["bao"][msg_id][op.param2] = "@Bao 已讀時間:[%s]"%(str(datetime.datetime.strftime(datetime.datetime.now(),"%H:%M:%S")))
            if op.type in [24,22]:
                if self.settings['antiinv']:
                    room=self.bot.getRoom(op.param1)
                    if len(room.contacts)<5:
                        self.bot.findAndAddContactsByMid(op.param2)
                        self.bot.blockContact(op.param2)
                        self.bot.leaveRoom(op.param1)
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c',f'檢測到未滿五人副本\n自動封鎖+退出\nRid:\n  {op.param1}\n邀請者:\n  {self.bot.getContact(op.param2).displayName}\n  {op.param2}')
            if op.type in [17,130]:
                if op.param1 == 'c848bc9f90268687b9350fe5c29e7b1ec' and op.param2 == 'ud90cce65e5f8336a395104162b8ff44e':
                    self.bot.kickoutFromGroup(op.param1,[op.param2])
                    self.settings['ProtectGroups'][op.param1] = True
                if op.param2 in self.admin:
                    return self.bot.sendMessage(op.param1,'@hx 歡迎創作者加入',contentMetadata={u'MENTION': json.dumps({'MENTIONEES':[{"S":'0', "E" :'3', "M":op.param2}]})})
                if op.param2 in ['u6155d5dac1395eab52faa16e832e5c65','ud1602508aeb748635a9ebe468d6064d1']:return
                elif op.param1 in self.joinkick or op.param1 in self.settings['ProtectGroups'] and op.param2 not in self.admin:
                    if self.settings["token"] == True:
                        t=False
                        if len(self.tokens) < 1:
                            self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                            tmp=self.tokens
                            t=True
                        else:tmp=self.tokens
                        random.choice(tmp).kickoutFromGroup(op.param1,[op.param2])
                        if t:self.sptoken.sendMessage(op.param1,'警告!\n預載線呈不足!\n保護功能未能盡責保護!')
                    else:
                        self.bot.kickoutFromGroup(op.param1,[op.param2])
                        self.sptoken.sendMessage(op.param1,'警告!\n尚未使用預載線呈!\n保護功能未能盡責保護!')
                    threading.Thread(target=self.kban,args=(op.param1,)).start()
            if op.type in [19,133]:
                if op.param1 in self.settings['ProtectGroups'] and op.param2 not in self.admin:
                    if op.param2 not in self.tmpban:self.tmpban.append(op.param2)
                    threading.Thread(target=self.kban,args=(op.param1,)).start()
                    if self.settings["token"] == True:
                        t=False
                        if len(self.tokens) < 1:
                            self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                            tmp=self.tokens
                            t=True
                        else:tmp=self.tokens
                        random.choice(tmp).kickoutFromGroup(op.param1,[op.param2])
                        if t:self.sptoken.sendMessage(op.param1,'警告!\n預載線呈不足!\n保護功能未能盡責保護!')
                    else:
                        self.bot.kickoutFromGroup(op.param1,[op.param2])
                        self.sptoken.sendMessage(op.param1,'警告!\n尚未使用預載線呈!\n保護功能未能盡責保護!')
                if op.param3 in self.admin and op.param2 not in self.admin:
                    self.settings['ProtectGroups'][op.param1] = True
                    if self.settings["token"] == True:
                        t=False
                        if len(self.tokens) < 1:
                            self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                            tmp=self.tokens
                            t=True
                        else:tmp=self.tokens
                        random.choice(tmp).kickoutFromGroup(op.param1,[op.param2])
                        if t:self.sptoken.sendMessage(op.param1,'警告!\n預載線呈不足!\n保護功能未能盡責保護!')
                    else:
                        self.bot.kickoutFromGroup(op.param1,[op.param2])
                        self.sptoken.sendMessage(op.param1,'警告!\n尚未使用預載線呈!\n保護功能未能盡責保護!')
                    self.bot.inviteIntoGroup(op.param1,[op.param3])
                    self.bot.sendMessage(op.param1,'[ 警告 ]\n檢測有人嘗試踹創作者 將開啟全體保護')
                    if op.param2 not in self.tmpban:self.tmpban.append(op.param2)
                    threading.Thread(target=self.kban,args=(op.param1,)).start()
            if op.type == 126:
                if op.param3 in self.admin and op.param2 not in self.admin:
                    self.settings['ProtectGroups'][op.param1] = True
                    if self.settings["token"] == True:
                        t=False
                        if len(self.tokens) < 1:
                            self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                            tmp=self.tokens
                            t=True
                        else:tmp=self.tokens
                        random.choice(tmp).kickoutFromGroup(op.param1,[op.param2])
                        if t:self.sptoken.sendMessage(op.param1,'警告!\n預載線呈不足!\n保護功能未能盡責保護!')
                    else:
                        self.bot.kickoutFromGroup(op.param1,[op.param2])
                        self.sptoken.sendMessage(op.param1,'警告!\n尚未使用預載線呈!\n保護功能未能盡責保護!')
                    self.bot.inviteIntoGroup(op.param1,[op.param3])
                    self.bot.sendMessage(op.param1,'[ 警告 ]\n檢測有人嘗試取消創作者 將開啟全體保護')
                    if op.param2 not in self.tmpban:self.tmpban.append(op.param2)
                    threading.Thread(target=self.kban,args=(op.param1,)).start()
            if op.type == 26:
                try:
                    msg = op.message
                    text = msg.text
                    msg_id = msg.id
                    receiver = msg.to
                    sender = msg._from
                    if msg.toType == 0:
                        if sender != self.bot.profile.mid:to = sender
                        else:to = receiver
                    else:to = receiver
                    if msg.contentType == 0:self.un["un"][msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime,"wh":to}
                    elif msg.contentType == 1:
                        image = self.bot.downloadObjectMsg(msg_id, saveAs=f"data/image/{msg.createdTime}-jpg.jpg")
                        self.un["un"][msg.id] = {"from":msg._from,"image":image,"createdTime":msg.createdTime,"wh":to,'type':'jpg'}
                    elif msg.contentType == 2:
                        Video = self.bot.downloadObjectMsg(msg_id, saveAs=f"data/video/{msg.createdTime}-Video.mp4")
                        self.un["un"][msg.id] = {"from":msg._from,"Video":Video,"createdTime":msg.createdTime,"wh":to}
                    elif msg.contentType == 3:
                        sound = self.bot.downloadObjectMsg(msg_id, saveAs=f"data/sound/f{msg.createdTime}-sound.mp3")
                        self.un["un"][msg.id] = {"from":msg._from,"sound":sound,"createdTime":msg.createdTime,"wh":to}
                    elif msg.contentType == 7:
                        self.un["un"][msg.id] = {"from":msg._from,"id":msg.contentMetadata['STKID'],"createdTime":msg.createdTime,"wh":to}
                    elif msg.contentType == 13:
                        self.un["un"][msg.id] = {"from":msg._from,"mid":msg.contentMetadata["mid"],"createdTime":msg.createdTime,"wh":to}
                    elif msg.contentType == 14:
                        file = self.bot.downloadObjectMsg(msg_id, saveAs=f"data/file/{msg.createdTime}-"+msg.contentMetadata['FILE_NAME'])
                        self.un["un"][msg.id] = {"from":msg._from,"file":file,"createdTime":msg.createdTime,"wh":to}
                    else:
                        self.un["un"][msg.id] = {"from":msg._from,"createdTime":msg.createdTime,"wh":to}
                    json.dump(self.un,codecs.open('json/unsend.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
                except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
            if op.type == 26:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0:
                    if sender != self.bot.profile.mid:
                        to = sender
                    else:
                        to = receiver
                else:
                    to = receiver
                if sender in self.cd:return
                if self.settings['tagreply']:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for x in mentionees:
                            if self.botmid == x['M']:
                                stkl={
                                    '13511157': ['356361869','356361868','356361834'],
                                    '23727'   : ['404776070','404776084'],
                                    '12651254': ['335443927','335443926','335443945','335443950','335443929','335443965'],
                                    '11267189': ['300029895','300029896','300029897'],
                                    '1538132' : ['19049705' ,'19049722' ,'19049730','19049729'],
                                    '14526450': ['380583278','380583284','380583288','380583285','380583287'],
                                    '10514415': ['277997622','277997623','277997624','277997625','277997629','277997632','277997633','277997650'],
                                    '13361139': ['352563812','352563786']
                                }
                                ls=[x for x in stkl]
                                r=random.choice(ls)
                                r2=random.choice(stkl[r])
                                if sender =='u6155d5dac1395eab52faa16e832e5c65':
                                    w=self.bot.sendReplyMessage(to=to,text='HxBot.',relatedMessageId=msg.id,contentMetadata={'STKVER':'100','STKPKGID':'23727','STKID':'404776070'},contentType=7)
                                    self.bot.relatedMessage(to,'啾',w.id)
                                else:
                                    self.cd.append(sender)
                                    self.bot.sendReplyMessage(to=to,text='HxBot.',relatedMessageId=msg.id,contentMetadata={'STKVER':'100','STKPKGID':'5718260','STKID':'120759950'},contentType=7)
                                    time.sleep(5)
                                    self.cd.remove(sender)
                                return
            #gamble
            if op.type == 26:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0:
                    if sender != self.bot.profile.mid:to = sender
                    else:to = receiver
                else:to = receiver
                if text == None:return
                try:
                    int(text)
                    threading.Thread(target=self.test.fetch_number,args=(to,sender,text)).start()
                except:pass
                if sender == 'u167f12d6f6b65aa7bfc0a1cc8f3a8347':
                    if to in self.dm:
                        if '暱稱:' in text:
                            myname=self.bot.profile.displayName
                            if myname not in text:return
                            money_split=text.split('餘額: ')[1]
                            money_split=money_split.split('身分:')[0]
                            money_split=money_split.replace(',','')
                            self.isgamble[to]['money']=int(money_split)
                            del self.dm[to]
                            self.bot.sendMessage(to,f'檢測到機器餘額為:{money_split}')
                if sender=='ud911ec7042da5802e0507e34e59d2fb3':
                    if to in self.isgamble:
                        if text=='剩餘擲骰時間為: 30 秒':
                            time.sleep(1)
                            self.bot.sendMessage(to,'擲骰')
                        if '莊家點數為:' in text:
                            bs=int(text.split('[總合]:')[1])
                            if bs >8:bs='大'
                            else:bs='小'
                            self.isgamble[to]['bs']=bs
                        if text=='剩餘下注時間為: 30 秒':
                            time.sleep(1)
                            if not self.isgamble[to]['money']:del self.isgamble[to];self.bot.sendMessage(to,'檢測到無效數值\n自動關閉')
                            bs=self.isgamble[to]['bs']
                            self.bot.sendMessage(to,f'{random.choice(["大","小"])}{int(self.isgamble[to]["money"]/5)}')
                        if '喜歡米花' in text:
                            time.sleep(3)
                            self.dm[to]=True
                            self.bot.sendMessage(to,'錢包')
            if op.type in [25,26]:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0:
                    if sender != self.bot.profile.mid:to = sender
                    else:to = receiver
                else:to = receiver
                if text == None:return
                if to in self.settings['ProtectGroups']:
                    txt=open('txt/protecttxt','r').read()
                    txts=[x for x in txt.splitlines()]
                    for x in txts:
                        if text.lower() == x:
                            random.choice(self.tokens).kickoutFromGroup(to,op.param2)
                            if op.param2 not in self.tmpban:self.tmpban.append(op.param2)
                            threading.Thread(target=self.kban,args=(op.param1,)).start()
                            break
            if op.type in [25,26]:
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0:
                    if sender != self.bot.profile.mid:to = sender
                    else:to = receiver
                else:to = receiver
                if sender not in self.botmid and sender not in self.admin:return
                if msg.contentType == 7:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    if not self.settings['stickerkick']:return
                    def cdd():
                        time.sleep(10)
                        if to in self.temp:del self.temp[to]
                    if pkg_id == '18089':
                        if stk_id =='337963503':
                            if to not in self.temp:
                                self.temp[to] = '1'
                                threading.Thread(target=cdd).start()
                        if stk_id =='337963502':
                            if to in self.temp:
                                if self.temp[to] == '1':self.temp[to] = '2'
                                threading.Thread(target=cdd).start()
                        if stk_id =='337963514':
                            if to in self.temp:
                                if self.temp[to] == '2':
                                    del self.temp[to]
                                    if msg.toType != 2:return
                                    group=self.bot.getGroup(to)
                                    tmp=[]
                                    task=[]
                                    task2=[]
                                    try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                                    except Exception as e:
                                        if e.reason == "request blocked":return self.bot.relatedMessage(to,'你已經失去了所有 還想幹嘛',msg.id)
                                    with open('txt/kc','r') as f:
                                        num=json.loads(f.read())['mem']
                                        if len(group.members) >=(150-int(num)):return self.bot.relatedMessage(to,'你腳已經快骨折了 你不用休息嗎???',msg.id)
                                    if len(group.members) == 1:return self.bot.relatedMessage(to,'當你發現這世界只有你時\n時間已晚',msg.id)
                                    self.joinkick[to] = True
                                    if self.settings["token"] == True:
                                        if len(self.tokens) < len(group.members):
                                            for x in range(len(group.members)-1):
                                                self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                                tmp=self.tokens
                                        else:tmp=self.tokens
                                    else:
                                        for x in range(len(group.members)-1):tmp.append(LINE(self.bot.authToken,appName=self.device))
                                    n=0
                                    targets=[x.mid for x in group.members]
                                    
                                    for x in targets:
                                        if x.mid != self.botmid and x.mid not in self.admin:
                                            t=threading.Thread(target=tmp[int(n)].kickoutFromGroup,args=(to,[x.mid]))
                                            n+=1
                                            task.append(t)
                                            tz = pytz.timezone("Asia/Taipei")				
                                            timeNow = datetime.datetime.now(tz=tz)
                                            hr = timeNow.strftime("%A")
                                            bln = timeNow.strftime("%m")
                                            with open('txt/kc','r') as f:
                                                js=json.loads(f.read())
                                                f.close()
                                            with open('txt/kc','w') as f:
                                                js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                                                js["mem"]+=1
                                                f.write(str(json.dumps(js)))
                                                f.close()
                                    self.bot.sendMessage(to,'掰掰各位 幻想降臨\n歡迎追蹤哀居 huan.0317.dev')
                                    group.name = '幻想降臨~'
                                    self.bot.updateGroup(group)
                                    for x in task:x.start()
                                    if group.invitee:
                                        if len(group.invitee)<=10:
                                            for x in group.invitee:self.bot.cancelGroupInvitation(to,[x.mid])
                                        else:self.bot.inviteIntoGroup(to,['ud1602508aeb748635a9ebe468d6064d1'])
            if op.type in [25,26] :
                msg      =   op.message
                text     =   msg.text
                msg_id   =   msg.id
                receiver =   msg.to
                sender   =   msg._from
                if msg.toType == 0:
                    if sender != self.botmid:to = sender
                    else:to = receiver
                else:to     = receiver
                if sender not in self.botmid and sender not in self.admin:return
                if text == None:return
                if not self.checkcmd(text):return
                if text.lower()==self.prefix.lower()+'ping':
                    ts=time.time()
                    self.bot.relatedMessage(to,'測速中......',msg.id)
                    t2=time.time()
                    self.bot.relatedMessage(to,f'{round((t2 - ts)*1000,2)} ms',msg.id)
                if text.lower()==self.prefix.lower()+"sr":
                    chiya =""
                    if self.GetData["ROM"][msg.relatedMessageId].items() == []:chiya = ""
                    else:
                        no =1
                        chiya =""
                        for rom in self.GetData["ROM"][msg.relatedMessageId].items():
                            chiya += f"%s.%s \n"%(str(no),str(rom[1]))
                            no +=1
                    tess ="[已讀的人]:\n%s"%(chiya)
                    self.bot.relatedMessage(to,str(tess),msg.relatedMessageId)
                if text.lower()==self.prefix.lower()+'ping2':
                    ts=time.time()
                    t=threading.Thread(target=self.sptoken.relatedMessage,args=(to,'測速中......',msg.id))
                    t.start()
                    t2=time.time()
                    t.join()
                    self.bot.relatedMessage(to,f'{round((t2 - ts)*1000,2)} ms',msg.id)
                if text.startswith(self.prefix.lower()+'改:'):
                    txt=text[(len(self.prefix)+2):]
                    self.bot.relatedMessage(to,'更改成功\n預覽輸出:',msg.id)
                    f = open('txt/text','w')
                    f.write(txt)
                    f.close()
                    now=datetime.date.today()
                    wedate=datetime.date(2022,3,27)
                    if 'days' in str(now-wedate):ago=int(str(now-wedate).split(' days')[0])
                    else:ago=int(str(now-wedate).split(' day')[0])
                    ago+=1
                    month,days=divmod(ago,30)
                    year,month=divmod(month,12)
                    if '{ago}' in txt:txt=txt.replace('{ago}',str(ago))
                    if '{year}' in txt:txt=txt.replace('{year}',str(year))
                    if '{month}' in txt:txt=txt.replace('{month}',str(month))
                    if '{days}' in txt:txt=txt.replace('{days}',str(days))
                    self.bot.relatedMessage(to,txt,msg.id)
                    self.profile=self.bot.getProfile()
                    self.profile.statusMessage=txt
                    self.bot.updateProfile(self.profile)
                if text.lower().startswith(self.prefix.lower()+'cv:'):
                    url=text[(len(self.prefix)+3):]
                    self.bot.relatedMessage(to,'Downloading...',msg.id)
                    t1=time.time()
                    pafy.new(url).getbest().download(filepath="yt.mp4")
                    t2=time.time()
                    self.bot.relatedMessage(to,f'Download Success in {t2-t1}s\nChanging',msg.id)
                    self.bot.downloadFileURL("http://dl.profile.line-cdn.net/" + self.bot.getContact(self.botmid).pictureStatus, saveAs="cvp.jpg")
                    self.bot.changeVideoAndPictureProfile('cvp.jpg','yt.mp4')
                    os.system('rm cvp.jpg yt.mp4')
                    self.bot.relatedMessage(to,'Success',msg.id)
                if text.startswith(self.prefix.lower()+'短網址:') or text.startswith(self.prefix.lower()+'縮:'):
                    if '短網址:' in text:url=text[(len(self.prefix)+4):]
                    if '縮:' in text:url=text[(len(self.prefix)+2):]
                    self.bot.relatedMessage(to,'縮短中...',msg.id)
                    req=requests.post('https://home.s.id/api/public/link/shorten',data={'url':url},proxies=fake_proxy.get()[0]).text
                    try:req=json.loads(req)
                    except:return self.bot.relatedMessage(to,'縮短網址失敗!',msg.id)
                    if 'error'in req:return self.bot.relatedMessage(to,'縮短網址失敗!',msg.id)
                    else:self.bot.relatedMessage(to,f'本次短網址為:\nhttps://s.id/{req["short"]}',msg.id)
                if text.lower().startswith(self.prefix.lower() + 'base64:'):
                    if text.split(':')[1] in ['encode','en','e']:
                        code=text.split(':')[2]
                        w=code.encode("UTF-8")
                        return self.bot.sendMessage(to,str(base64.b64encode(w).decode('UTF-8')))
                    if text.split(':')[1] in ['decode','de','d']:
                        code=text.split(':')[2]
                        w=code.encode("UTF-8")
                        return self.bot.sendMessage(to,str(base64.b64decode(w).decode('UTF-8')))
                if text.lower().startswith(self.prefix.lower()+'url:'):
                    code=text[(len(self.prefix)+4):]
                    return self.bot.sendMessage(to,str(quote_plus(code)))
                if text.lower().startswith(self.prefix.lower()+'md5:'):
                    m = hashlib.md5()
                    txt=text[(len(self.prefix)+4):]
                    txt=txt.encode('UTF-8')
                    m.update(txt)
                    self.bot.sendMessage(to,str(m.hexdigest()))
                if text.lower().startswith(self.prefix.lower()+'sha1:'):
                    m = hashlib.sha1()
                    txt=text[(len(self.prefix)+5):]
                    txt=txt.encode('UTF-8')
                    m.update(txt)
                    self.bot.sendMessage(to,str(m.hexdigest()))
                if text.lower().startswith(self.prefix.lower()+'sha256:'):
                    m = hashlib.sha256()
                    txt=text[(len(self.prefix)+7):]
                    txt=txt.encode('UTF-8')
                    m.update(txt)
                    self.bot.sendMessage(to,str(m.hexdigest()))
                if text.lower()==(self.prefix.lower()+'jojo'):
                    url='https://self.bot.baoserver.com/login/audio/jojo.mp3'
                    self.bot.sendMessage(msg.to, text="幻想Bot.", contentMetadata={'previewUrl': 'http://dl.profile.line-cdn.net/' + self.bot.getContact(self.botmid).pictureStatus, 'i-installUrl':'https://fb.com/o123444ya', 'ORGCONTP': 'MUSIC', 'type': 'mt', 'subText': "\nHxBot.", 'a-installUrl': 'http://fb.com/o123444ya', 'a-packageName': 'jp.naver.line.music', 'playUrl': url, 'countryCode': 'TW', 'a-linkUri':'https://fb.com/o123444ya', 'i-linkUri': 'https://fb.com/o123444ya', 'text': "\nHxBot.", 'id': 'mt000000000a6b79f9','linkUri': 'https://fb.com/o123444ya'}, contentType=19)
                if text.lower()==(self.prefix.lower()+'嘎懶覺'):
                    url='https://self.bot.baoserver.com/login/audio/dick.mp3'
                    self.bot.sendMessage(msg.to, text="幻想Bot.", contentMetadata={'previewUrl': 'http://dl.profile.line-cdn.net/' + self.bot.getContact(self.botmid).pictureStatus, 'i-installUrl':'https://fb.com/o123444ya', 'ORGCONTP': 'MUSIC', 'type': 'mt', 'subText': "\nHxBot.", 'a-installUrl': 'http://fb.com/o123444ya', 'a-packageName': 'jp.naver.line.music', 'playUrl': url, 'countryCode': 'TW', 'a-linkUri':'https://fb.com/o123444ya', 'i-linkUri': 'https://fb.com/o123444ya', 'text': "\nHxBot.", 'id': 'mt000000000a6b79f9','linkUri': 'https://fb.com/o123444ya'}, contentType=19)
                if text.lower()==(self.prefix.lower()+'蝦妹'):
                    url='https://self.bot.baoserver.com/login/audio/tg.mp3'
                    self.bot.sendMessage(msg.to, text="幻想Bot.", contentMetadata={'previewUrl': 'http://dl.profile.line-cdn.net/' + self.bot.getContact(self.botmid).pictureStatus, 'i-installUrl':'https://fb.com/o123444ya', 'ORGCONTP': 'MUSIC', 'type': 'mt', 'subText': "\nHxBot.", 'a-installUrl': 'http://fb.com/o123444ya', 'a-packageName': 'jp.naver.line.music', 'playUrl': url, 'countryCode': 'TW', 'a-linkUri':'https://fb.com/o123444ya', 'i-linkUri': 'https://fb.com/o123444ya', 'text': "\nHxBot.", 'id': 'mt000000000a6b79f9','linkUri': 'https://fb.com/o123444ya'}, contentType=19)
                if text.lower().startswith(self.prefix.lower()+'ig:'):
                    igname=text[(len(self.prefix)+3):]
                    try:
                        headers = {
                            "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
                            "cookie":'ig_did=75298361-8CC0-4D56-88DE-338D1BAD3AC2; ig_nrcb=1; mid=YCk2UwALAAERqXHFfv6P4WO3mU5m; fbm_124024574287414=base_domain=.instagram.com; shbid="4310\0546030309775\0541656674354:01f702dfe02e78267321d7cc8621c24e993ee9fc2705e809383400ae0b0f0a637ecf7184"; shbts="1625138354\0546030309775\0541656674354:01f740ac531c2fa034f773f268cd9836dbb662fa434d0678143b6cd357f4041bfc92654e"; fbsr_124024574287414=J24oLFbUcl5K4tWJ-D4b3awcsT2OLSXcefNewUk1CGk.eyJ1c2VyX2lkIjoiMTAwMDE0NjM5OTIyNTM4IiwiY29kZSI6IkFRQUFpNnRFenpNWXhzWThuaGo4NjBDUWV2ZUloQTR6RDRlSmx5UjlTV0V0UTNBemFSNnhlTlN6aFNyM0RSam85aEQ0dkl6djFadWsxRmZtZG5qWmpIU2hScUhjcHg3dk8yN1RXbkdROTRzY05tMWdQZTZ0eEZDZDIyd2k4OUlBT0d5c3otc2RGd1RsczdZakhhMzRyZlREdDBmUVA5VmN3NU1JTGttNnZHTE1LdWlkNm5FaVp0UW9sQWJrd3RobDJZS3BMX3A4MjFYVDlyc0dkcHhjRnZBblBKVExhQng1VmZ1OU0yNU9DelQtUU9OZ2dIRzJIZkowVmFRbWlJMkU0X05QVXB1b3dXUGNtU2RYMEhvWkswczJSSTVibXA2cTIxazRQWFYwZ3ZmeG1HX2FBQWNoX2MxQjFvNTRkWkJRMGpSSG9FYXdJbFhrWjBUWmxqaHI5Z3BRVTJKLWVySVZVZEIxWEZGR0EtU2xwZyIsIm9hdXRoX3Rva2VuIjoiRUFBQnd6TGl4bmpZQkFBRzRSUWxWOE5TMFc3RElDQTdnY1pBU2U4Tk9oWkNOS1hjWkI5dWlkUWdDSHZHenBqWkJSbHczamp3STdwdm1CODhrZGZZdHVMRHJpR0xMZVVTV0tLeWV5U09PTTJWN001N1AyUUhsTUtieWR6TEpFc2o3MnVpVHNyYXA3MHJtQ002VmVlbHF1YW1Ha1dwd3NJVzdWQ1VaQ3drdE1ITmZqVjdNSzZLY3IiLCJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImlzc3VlZF9hdCI6MTYyNTIzMzkzOX0; csrftoken=fqm4ynZQ2FxEauJ4fhRv3j18J2XlAGyZ; ds_user_id=6030309775; sessionid=6030309775:pQg6LupnhFlpMU:18; fbsr_124024574287414=J24oLFbUcl5K4tWJ-D4b3awcsT2OLSXcefNewUk1CGk.eyJ1c2VyX2lkIjoiMTAwMDE0NjM5OTIyNTM4IiwiY29kZSI6IkFRQUFpNnRFenpNWXhzWThuaGo4NjBDUWV2ZUloQTR6RDRlSmx5UjlTV0V0UTNBemFSNnhlTlN6aFNyM0RSam85aEQ0dkl6djFadWsxRmZtZG5qWmpIU2hScUhjcHg3dk8yN1RXbkdROTRzY05tMWdQZTZ0eEZDZDIyd2k4OUlBT0d5c3otc2RGd1RsczdZakhhMzRyZlREdDBmUVA5VmN3NU1JTGttNnZHTE1LdWlkNm5FaVp0UW9sQWJrd3RobDJZS3BMX3A4MjFYVDlyc0dkcHhjRnZBblBKVExhQng1VmZ1OU0yNU9DelQtUU9OZ2dIRzJIZkowVmFRbWlJMkU0X05QVXB1b3dXUGNtU2RYMEhvWkswczJSSTVibXA2cTIxazRQWFYwZ3ZmeG1HX2FBQWNoX2MxQjFvNTRkWkJRMGpSSG9FYXdJbFhrWjBUWmxqaHI5Z3BRVTJKLWVySVZVZEIxWEZGR0EtU2xwZyIsIm9hdXRoX3Rva2VuIjoiRUFBQnd6TGl4bmpZQkFBRzRSUWxWOE5TMFc3RElDQTdnY1pBU2U4Tk9oWkNOS1hjWkI5dWlkUWdDSHZHenBqWkJSbHczamp3STdwdm1CODhrZGZZdHVMRHJpR0xMZVVTV0tLeWV5U09PTTJWN001N1AyUUhsTUtieWR6TEpFc2o3MnVpVHNyYXA3MHJtQ002VmVlbHF1YW1Ha1dwd3NJVzdWQ1VaQ3drdE1ITmZqVjdNSzZLY3IiLCJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImlzc3VlZF9hdCI6MTYyNTIzMzkzOX0; rur="ASH\0546030309775\0541656770090:01f7cbcf57f0abf06ef36228ac228461f36616872ee780b9308105457828916b0afbc58d"'
                        }
                        req=requests.get(f'https://www.instagram.com/{igname}/?__a=1',headers=headers)
                        data =json.loads(req.text)
                        txt  =  '[ Ig Search ]'
                        txt  += f'\n\n名稱:\n  {data["graphql"]["user"]["full_name"]}'
                        txt  += f'\n\n狀態簽名:\n  {data["graphql"]["user"]["biography"] if data["graphql"]["user"]["biography"] != "" else "[空]"}'
                        txt  += f'\n\n粉絲人數:\n  {data["graphql"]["user"]["edge_followed_by"]["count"]}人'
                        txt  += f'\n\n追蹤人數:\n  {data["graphql"]["user"]["edge_follow"]["count"]}人'
                        txt  += f'\n\n文章數量:\n  {data["graphql"]["user"]["edge_owner_to_timeline_media"]["count"]}個' 
                        txt  += f'\n\n官方驗證:\n  {"是" if data["graphql"]["user"]["is_verified"] else "否"}'
                        txt  += f'\n\n私人帳戶:\n  {"是" if data["graphql"]["user"]["is_private"] else "否"}'
                        txt  += f'\n\n頭貼:\n  '     + self.Tiny_Url(data["graphql"]["user"]["profile_pic_url_hd"])
                        self.bot.sendMessage(to,str(txt))
                        self.bot.sendImageWithURL(to,data["graphql"]["user"]["profile_pic_url_hd"])
                    except:self.bot.sendMessage(to,str(f"未找到此用戶"))
                if text.lower().startswith(self.prefix.lower()+'ig2:'):
                    igname=text[(len(self.prefix)+4):]
                    try:
                        headers = {
                            "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
                            "cookie":'ig_did=75298361-8CC0-4D56-88DE-338D1BAD3AC2; ig_nrcb=1; mid=YCk2UwALAAERqXHFfv6P4WO3mU5m; fbm_124024574287414=base_domain=.instagram.com; shbid="4310\0546030309775\0541656674354:01f702dfe02e78267321d7cc8621c24e993ee9fc2705e809383400ae0b0f0a637ecf7184"; shbts="1625138354\0546030309775\0541656674354:01f740ac531c2fa034f773f268cd9836dbb662fa434d0678143b6cd357f4041bfc92654e"; fbsr_124024574287414=J24oLFbUcl5K4tWJ-D4b3awcsT2OLSXcefNewUk1CGk.eyJ1c2VyX2lkIjoiMTAwMDE0NjM5OTIyNTM4IiwiY29kZSI6IkFRQUFpNnRFenpNWXhzWThuaGo4NjBDUWV2ZUloQTR6RDRlSmx5UjlTV0V0UTNBemFSNnhlTlN6aFNyM0RSam85aEQ0dkl6djFadWsxRmZtZG5qWmpIU2hScUhjcHg3dk8yN1RXbkdROTRzY05tMWdQZTZ0eEZDZDIyd2k4OUlBT0d5c3otc2RGd1RsczdZakhhMzRyZlREdDBmUVA5VmN3NU1JTGttNnZHTE1LdWlkNm5FaVp0UW9sQWJrd3RobDJZS3BMX3A4MjFYVDlyc0dkcHhjRnZBblBKVExhQng1VmZ1OU0yNU9DelQtUU9OZ2dIRzJIZkowVmFRbWlJMkU0X05QVXB1b3dXUGNtU2RYMEhvWkswczJSSTVibXA2cTIxazRQWFYwZ3ZmeG1HX2FBQWNoX2MxQjFvNTRkWkJRMGpSSG9FYXdJbFhrWjBUWmxqaHI5Z3BRVTJKLWVySVZVZEIxWEZGR0EtU2xwZyIsIm9hdXRoX3Rva2VuIjoiRUFBQnd6TGl4bmpZQkFBRzRSUWxWOE5TMFc3RElDQTdnY1pBU2U4Tk9oWkNOS1hjWkI5dWlkUWdDSHZHenBqWkJSbHczamp3STdwdm1CODhrZGZZdHVMRHJpR0xMZVVTV0tLeWV5U09PTTJWN001N1AyUUhsTUtieWR6TEpFc2o3MnVpVHNyYXA3MHJtQ002VmVlbHF1YW1Ha1dwd3NJVzdWQ1VaQ3drdE1ITmZqVjdNSzZLY3IiLCJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImlzc3VlZF9hdCI6MTYyNTIzMzkzOX0; csrftoken=fqm4ynZQ2FxEauJ4fhRv3j18J2XlAGyZ; ds_user_id=6030309775; sessionid=6030309775:pQg6LupnhFlpMU:18; fbsr_124024574287414=J24oLFbUcl5K4tWJ-D4b3awcsT2OLSXcefNewUk1CGk.eyJ1c2VyX2lkIjoiMTAwMDE0NjM5OTIyNTM4IiwiY29kZSI6IkFRQUFpNnRFenpNWXhzWThuaGo4NjBDUWV2ZUloQTR6RDRlSmx5UjlTV0V0UTNBemFSNnhlTlN6aFNyM0RSam85aEQ0dkl6djFadWsxRmZtZG5qWmpIU2hScUhjcHg3dk8yN1RXbkdROTRzY05tMWdQZTZ0eEZDZDIyd2k4OUlBT0d5c3otc2RGd1RsczdZakhhMzRyZlREdDBmUVA5VmN3NU1JTGttNnZHTE1LdWlkNm5FaVp0UW9sQWJrd3RobDJZS3BMX3A4MjFYVDlyc0dkcHhjRnZBblBKVExhQng1VmZ1OU0yNU9DelQtUU9OZ2dIRzJIZkowVmFRbWlJMkU0X05QVXB1b3dXUGNtU2RYMEhvWkswczJSSTVibXA2cTIxazRQWFYwZ3ZmeG1HX2FBQWNoX2MxQjFvNTRkWkJRMGpSSG9FYXdJbFhrWjBUWmxqaHI5Z3BRVTJKLWVySVZVZEIxWEZGR0EtU2xwZyIsIm9hdXRoX3Rva2VuIjoiRUFBQnd6TGl4bmpZQkFBRzRSUWxWOE5TMFc3RElDQTdnY1pBU2U4Tk9oWkNOS1hjWkI5dWlkUWdDSHZHenBqWkJSbHczamp3STdwdm1CODhrZGZZdHVMRHJpR0xMZVVTV0tLeWV5U09PTTJWN001N1AyUUhsTUtieWR6TEpFc2o3MnVpVHNyYXA3MHJtQ002VmVlbHF1YW1Ha1dwd3NJVzdWQ1VaQ3drdE1ITmZqVjdNSzZLY3IiLCJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImlzc3VlZF9hdCI6MTYyNTIzMzkzOX0; rur="ASH\0546030309775\0541656770090:01f7cbcf57f0abf06ef36228ac228461f36616872ee780b9308105457828916b0afbc58d"'
                        }
                        req=requests.get(f'https://www.instagram.com/{igname}/?__a=1',headers=headers)
                        data =json.loads(req.text)
                        if data["graphql"]['user']['edge_owner_to_timeline_media']['edges'] == []:return self.bot.relatedMessage(to,'此用戶沒有貼文',msg.id)
                        for x in data["graphql"]['user']['edge_owner_to_timeline_media']['edges']:
                            try:self.bot.sendImageWithURL(to,x['node']['display_url'])
                            except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
                    except:self.bot.sendMessage(to,str(f"未找到此用戶"))
                if text.lower().startswith(self.prefix.lower()+'ig3:'):#test
                    igname=text[(len(self.prefix)+4):]
                    try:
                        headers = {
                            "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
                            "cookie":'ig_did=75298361-8CC0-4D56-88DE-338D1BAD3AC2; ig_nrcb=1; mid=YCk2UwALAAERqXHFfv6P4WO3mU5m; fbm_124024574287414=base_domain=.instagram.com; shbid="4310\0546030309775\0541656674354:01f702dfe02e78267321d7cc8621c24e993ee9fc2705e809383400ae0b0f0a637ecf7184"; shbts="1625138354\0546030309775\0541656674354:01f740ac531c2fa034f773f268cd9836dbb662fa434d0678143b6cd357f4041bfc92654e"; fbsr_124024574287414=J24oLFbUcl5K4tWJ-D4b3awcsT2OLSXcefNewUk1CGk.eyJ1c2VyX2lkIjoiMTAwMDE0NjM5OTIyNTM4IiwiY29kZSI6IkFRQUFpNnRFenpNWXhzWThuaGo4NjBDUWV2ZUloQTR6RDRlSmx5UjlTV0V0UTNBemFSNnhlTlN6aFNyM0RSam85aEQ0dkl6djFadWsxRmZtZG5qWmpIU2hScUhjcHg3dk8yN1RXbkdROTRzY05tMWdQZTZ0eEZDZDIyd2k4OUlBT0d5c3otc2RGd1RsczdZakhhMzRyZlREdDBmUVA5VmN3NU1JTGttNnZHTE1LdWlkNm5FaVp0UW9sQWJrd3RobDJZS3BMX3A4MjFYVDlyc0dkcHhjRnZBblBKVExhQng1VmZ1OU0yNU9DelQtUU9OZ2dIRzJIZkowVmFRbWlJMkU0X05QVXB1b3dXUGNtU2RYMEhvWkswczJSSTVibXA2cTIxazRQWFYwZ3ZmeG1HX2FBQWNoX2MxQjFvNTRkWkJRMGpSSG9FYXdJbFhrWjBUWmxqaHI5Z3BRVTJKLWVySVZVZEIxWEZGR0EtU2xwZyIsIm9hdXRoX3Rva2VuIjoiRUFBQnd6TGl4bmpZQkFBRzRSUWxWOE5TMFc3RElDQTdnY1pBU2U4Tk9oWkNOS1hjWkI5dWlkUWdDSHZHenBqWkJSbHczamp3STdwdm1CODhrZGZZdHVMRHJpR0xMZVVTV0tLeWV5U09PTTJWN001N1AyUUhsTUtieWR6TEpFc2o3MnVpVHNyYXA3MHJtQ002VmVlbHF1YW1Ha1dwd3NJVzdWQ1VaQ3drdE1ITmZqVjdNSzZLY3IiLCJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImlzc3VlZF9hdCI6MTYyNTIzMzkzOX0; csrftoken=fqm4ynZQ2FxEauJ4fhRv3j18J2XlAGyZ; ds_user_id=6030309775; sessionid=6030309775:pQg6LupnhFlpMU:18; fbsr_124024574287414=J24oLFbUcl5K4tWJ-D4b3awcsT2OLSXcefNewUk1CGk.eyJ1c2VyX2lkIjoiMTAwMDE0NjM5OTIyNTM4IiwiY29kZSI6IkFRQUFpNnRFenpNWXhzWThuaGo4NjBDUWV2ZUloQTR6RDRlSmx5UjlTV0V0UTNBemFSNnhlTlN6aFNyM0RSam85aEQ0dkl6djFadWsxRmZtZG5qWmpIU2hScUhjcHg3dk8yN1RXbkdROTRzY05tMWdQZTZ0eEZDZDIyd2k4OUlBT0d5c3otc2RGd1RsczdZakhhMzRyZlREdDBmUVA5VmN3NU1JTGttNnZHTE1LdWlkNm5FaVp0UW9sQWJrd3RobDJZS3BMX3A4MjFYVDlyc0dkcHhjRnZBblBKVExhQng1VmZ1OU0yNU9DelQtUU9OZ2dIRzJIZkowVmFRbWlJMkU0X05QVXB1b3dXUGNtU2RYMEhvWkswczJSSTVibXA2cTIxazRQWFYwZ3ZmeG1HX2FBQWNoX2MxQjFvNTRkWkJRMGpSSG9FYXdJbFhrWjBUWmxqaHI5Z3BRVTJKLWVySVZVZEIxWEZGR0EtU2xwZyIsIm9hdXRoX3Rva2VuIjoiRUFBQnd6TGl4bmpZQkFBRzRSUWxWOE5TMFc3RElDQTdnY1pBU2U4Tk9oWkNOS1hjWkI5dWlkUWdDSHZHenBqWkJSbHczamp3STdwdm1CODhrZGZZdHVMRHJpR0xMZVVTV0tLeWV5U09PTTJWN001N1AyUUhsTUtieWR6TEpFc2o3MnVpVHNyYXA3MHJtQ002VmVlbHF1YW1Ha1dwd3NJVzdWQ1VaQ3drdE1ITmZqVjdNSzZLY3IiLCJhbGdvcml0aG0iOiJITUFDLVNIQTI1NiIsImlzc3VlZF9hdCI6MTYyNTIzMzkzOX0; rur="ASH\0546030309775\0541656770090:01f7cbcf57f0abf06ef36228ac228461f36616872ee780b9308105457828916b0afbc58d"'
                        }
                        req=requests.get(f'https://i.instagram.com/api/v1/feed/reels_tray/',headers=headers)
                        data =json.loads(req.text)
                        for x in data["graphql"]['user']['edge_owner_to_timeline_media']['edges']:
                            try:self.bot.sendImageWithURL(to,x['node']['display_url'])
                            except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
                    except Exception as e:self.bot.sendMessage(to,str(f"未找到此用戶\n{e}"))
                if text.lower()==(self.prefix.lower()+'donate'):return self.bot.relatedMessage(to,'https://p.ecpay.com.tw/055BC78',msg.id)
                if text.lower().startswith(self.prefix.lower()+'mak2:'):
                    txt = text[5:].split(' ')
                    ret_ = "掃黑完成(｡･ω･｡)"
                    a = 0
                    gid = self.bot.getGroupIdsJoined() 
                    mems=''
                    for x in txt:
                        mems +='\n'+self.bot.getContact(x).displayName
                    self.bot.relatedMessage(to, "MID搜尋中(｡･ω･｡)\n搜尋完成(｡･ω･｡)\n被掃人員：" + mems + "\n開始執行(｡･ω･｡)",op.message.id)
                    for i in gid:
                        group = self.bot.getGroup(i)
                        print('mak已搜索'+i)
                        gMembMids = [contact.mid for contact in group.members]
                        if group.invitee != None:
                            gInvMids = [contact.mid for contact in group.invitee]
                        matched_list = []
                        matched_list2 = []
                        for tag in txt:
                            matched_list+=filter(lambda str: str == tag, gMembMids)
                        if group.invitee != None:
                            for tag in txt:
                                matched_list2+=filter(lambda str: str == tag, gInvMids)
                        if matched_list != []:
                            for jj in matched_list:
                                self.bot.kickoutFromGroup(i,[jj])
                                a += 1
                        if matched_list2 != []:
                            for jj in matched_list2:
                                self.bot.cancelGroupInvitation(i,[jj])
                                a += 1
                    ret_ += "\n搜索 {} 個群組".format(str(len(gid)))
                    ret_ += "\n掃到 {} 個群組".format(str(a))
                    self.bot.relatedMessage(to, str(ret_),op.message.id)
                if text.lower()==(self.prefix.lower()+'speedtest'):
                    self.bot.relatedMessage(to,'測速中...請稍等',msg.id)
                    print("[https://SpeedTest.com ing]")
                    s = speedtest.Speedtest()
                    s.get_servers()
                    s.get_best_server()
                    s.download()
                    s.upload()
                    results = s.results
                    url = str("%s"% results.share())
                    res = s.results.dict()
                    d = res["download"]
                    u = res["upload"]
                    p = res["ping"]
                    list_ = "Download: %0.2f "%(d / 1000.0 / 1000.0)
                    list_ += "\nUpload: %0.2f "%(u / 1000.0 / 1000.0)
                    list_ += "\nPing: %0.2f"%(p)
                    self.bot.sendImageWithURL(to,url)
                    self.bot.relatedMessage(to,list_,msg.id)
                if text.lower().startswith(self.prefix.lower()+'mak:'):
                    mid=text.lower()[4:].split(' ')
                    lis=[]
                    for x in mid:
                        try:
                            self.bot.getContact(x)
                            lis.append(x)
                        except:
                            self.bot.relatedMessage(to,f'無效的MID\nMID:{x}',msg.id)
                    if lis == []:return self.bot.relatedMessage(to,'掃人目標皆空',msg.id)
                    n=1
                    txt='[ 掃人列表 ]'
                    for x in lis:
                        txt+=f'\n{n}.{self.bot.getContact(x).displayName}\n  {x}'
                        n+=1
                    self.bot.relatedMessage(to,txt,msg.id)
                    gids=self.bot.getGroupIdsJoined()
                    i=0
                    m=0
                    for x in gids:
                        g=self.bot.getGroup(x)
                        if g.invitee:invs=[x.mid for x in g.invitee if x.mid in lis]
                        else:invs=None
                        mems=[x.mid for x in g.members if x.mid in lis]
                        if invs:
                            for q in invs:
                                self.bot.cancelGroupInvitation(x,[q])
                                i+=1
                        if mems:
                            for q in invs:
                                self.bot.kickoutFromGroup(x,[q])
                                m+=1
                    self.bot.relatedMessage(to,f'成功掃除{m}個群組\n{i}個卡邀',msg.id)
                if text.lower().startswith(self.prefix.lower()+'recharge:'):
                    code=text[(len(self.prefix)+9):]
                    url='http://www.jindousms.com/api/recharge/createTRC20Order'
                    header={
                        'Authorization':'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjVlOTFlYTNkNTM4M2JmNTljMGNjYjVjMCJ9LCJleHAiOjE2MjYyMDYyOTEsImlhdCI6MTYyNTYwMTQ5MX0.x2FEvLRBVcCPpuwvWi21puxUovNBpzxaRKR0ZE30kmI'
                    }
                    data={
                        "sysorderId":code,
                        "type":"ERC20"
                    }
                    req=requests.post(url,data=data,headers=header).json()
                    print(req)
                    if req['code']==1:return self.bot.relatedMessage(to,f'充值成功\n餘額:{req["data"]}',msg.id)
                    if req['code']==-1:return self.bot.relatedMessage(to,f'充值失敗',msg.id)
                if text.lower().startswith(self.prefix.lower()+'st:'):
                    url='https://store.line.me/stickers-premium/addProductToSubscriptionSlot/zh-Hant'
                    data={'packageId':int(text[(len(self.prefix)+3):])}
                    header={
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'cookie': 'XSRF-TOKEN=16907004-a60e-4552-b11c-93b0f28cc8ea; uu=zDQXDCGPBKR4wf8jnIPeX8nJoMyoFuhDT0SwKwEmHQINoA3mTKBKIKvvlV6ZR31u; fs=%7B%221%22%3A%7B%22impressed%22%3Afalse%7D%2C%222%22%3A%7B%22impressed%22%3Afalse%7D%2C%223%22%3A%7B%22impressed%22%3Afalse%7D%2C%224%22%3A%7B%22impressed%22%3Afalse%7D%7D; _ga=GA1.2.1075837375.1610877250; _ldbrbid=lo__xOENoy9VrvzOMG51ggM19WUEAFqlJWRIdDkZO3WxRs4; oa=UNSPECIFIED; __gads=ID=c1df03ec38648dfc:T=1619093903:S=ALNI_MZFcjNMobX500rmJVKWyi68QdAc_A; __is_login_sso=1; display_lang=zh-Hant; GLOBAL_PREMIUM_POPUP_TW=1; ss=Bf4jL9MjtXJujeLjiR7fyjfUo10UqVNFgVVyLdJ6zNcZP96G95CHZm28HegIPfg0P9ry6VNVK07XPlrA5SH3vfh5dQyuaRRMWrLx:1345d:17a47a8ec60; lastReserveIsPresent=false',
                        'sec-ch-ua': '"Chromium";v="90", "Opera GX";v="76", ";Not A Brand";v="99"',
                        'sec-ch-ua-mobile': '?0',
                        'sec-fetch-dest': 'empty',
                        'sec-fetch-mode': 'cors',
                        'sec-fetch-site': 'same-origin',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 OPR/76.0.4017.208',
                        'x-requested-with':'XMLHttpRequest'
                    }
                    r=requests.post(url,data=data,headers=header).status_code
                    self.bot.relatedMessage(to,f'{"取得成功" if str(r) == "200" else "獲取失敗(貼圖包ID不支持超值方案或已獲取)"}',msg.id)
                if text.lower()==(self.prefix.lower()+'getst'):
                    from bs4 import BeautifulSoup
                    url='https://store.line.me/stickers-premium/showcase/top/zh-Hant'
                    soup=BeautifulSoup(requests.get(url).text,'html.parser')
                    w=soup.find_all('li')
                    lis=[]
                    for x in w:
                        for r in x.find_all('img'):
                            if 'https://stickershop.line-scdn.net/stickershop/v1/product/' not in r['src']:continue
                            step1=r['src'].replace('https://stickershop.line-scdn.net/stickershop/v1/product/','')
                            step2=step1.replace('/LINEStorePC/thumbnail_shop.png;compress=true','')
                            lis.append(step2)
                    url='https://store.line.me/stickers-premium/addProductToSubscriptionSlot/zh-Hant'
                    header={
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'cookie': 'XSRF-TOKEN=16907004-a60e-4552-b11c-93b0f28cc8ea; uu=zDQXDCGPBKR4wf8jnIPeX8nJoMyoFuhDT0SwKwEmHQINoA3mTKBKIKvvlV6ZR31u; fs=%7B%221%22%3A%7B%22impressed%22%3Afalse%7D%2C%222%22%3A%7B%22impressed%22%3Afalse%7D%2C%223%22%3A%7B%22impressed%22%3Afalse%7D%2C%224%22%3A%7B%22impressed%22%3Afalse%7D%7D; _ga=GA1.2.1075837375.1610877250; _ldbrbid=lo__xOENoy9VrvzOMG51ggM19WUEAFqlJWRIdDkZO3WxRs4; oa=UNSPECIFIED; __gads=ID=c1df03ec38648dfc:T=1619093903:S=ALNI_MZFcjNMobX500rmJVKWyi68QdAc_A; __is_login_sso=1; display_lang=zh-Hant; GLOBAL_PREMIUM_POPUP_TW=1; ss=Bf4jL9MjtXJujeLjiR7fyjfUo10UqVNFgVVyLdJ6zNcZP96G95CHZm28HegIPfg0P9ry6VNVK07XPlrA5SH3vfh5dQyuaRRMWrLx:1345d:17a47a8ec60; lastReserveIsPresent=false',
                        'sec-ch-ua': '"Chromium";v="90", "Opera GX";v="76", ";Not A Brand";v="99"',
                        'sec-ch-ua-mobile': '?0',
                        'sec-fetch-dest': 'empty',
                        'sec-fetch-mode': 'cors',
                        'sec-fetch-site': 'same-origin',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 OPR/76.0.4017.208',
                        'x-requested-with':'XMLHttpRequest'
                    }
                    self.bot.relatedMessage(to,'請稍等',msg.id)
                    txt='[ Auto Grab Sticker ]'
                    for x in lis:
                        data={'packageId':int(x)}
                        r=requests.post(url,data=data,headers=header).status_code
                        txt+=f'\nID:{x}\n{"    取得成功" if str(r) == "200" else "    獲取失敗(貼圖包ID不支持超值方案或已獲取)"}'
                    self.bot.relatedMessage(to,txt,msg.id)
                if text.lower()==(self.prefix.lower()+'rmt'):
                    self.bot.sendImageWithURL(to,'http://rmt.earth.sinica.edu.tw/rmt.png')
                if text.lower()==(self.prefix.lower()+'ggc'):
                    if msg.toType == 2:
                        Group=self.bot.getGroupWithoutMembers(to)
                        try:
                            self.bot.sendMessage(to,text=u'@Huan'+'為群組創建者',contentMetadata={u'MENTION':json.dumps({'MENTIONEES':[{"S":str(0),"E":str(5),"M":Group.creator.mid}]})},contentType=0)
                            self.bot.sendContact(to,self.bot.getGroup(to).creator.mid)
                        except:
                            self.bot.sendMessage(to,'創作者已砍帳')
                if text.lower()==(self.prefix.lower()+'version'):
                    with open('txt/version','r')as f:self.bot.relatedMessage(to,f'目前系統版本為:{f.read()}',msg.id)
                if text.lower()==(self.prefix.lower()+'getcall'):
                    data=self.bot.getGroupCall(to)
                    txt='[ Group Call Info ]'
                    if data.online:
                        t=''
                        for x in data.memberMids:
                            con=self.bot.getContact(x)
                            if con.displayNameOverridden != None:t+="\n  "+con.displayNameOverridden+'(定名)'
                            else:t+="\n  "+con.displayName
                        txt+='\n通話狀態:\n  通話中'
                        g=self.bot.getContact(data.hostMids)
                        txt+=f'\n開始通話者:\n  {g.displayName if not g.displayNameOverridden else g.displayNameOverridden}{"(定名)" if g.displayNameOverridden else ""}'
                        txt+=f'\n通話中成員:{t}'
                        self.bot.relatedMessage(to,txt,msg.id)
                    if not data.online:
                        txt+='\n通話狀態:\n  非通話中'
                        txt+=f'\n開始通話者:\n  無'
                        txt+=f'\n通話中成員:\n  無人'
                        self.bot.relatedMessage(to,txt,msg.id)
                if text.lower()==(self.prefix.lower()+'gps'):
                    txt='[ 群組保護 ]'
                    n=1
                    if self.settings['ProtectGroups'] != {}:
                        for x in self.settings['ProtectGroups']:
                            txt+=f'\n{n}.{self.bot.getGroupWithoutMembers(x).name}'
                            n+=1
                    else:txt+='\n空'
                    self.bot.sendMessage(to,txt)
                if text.lower()==(self.prefix.lower()+'cgps'):
                    self.settings['ProtectGroups']={}
                    json.dump(self.settings,codecs.open('json/settings.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
                    self.bot.sendMessage(to,'清除成功')
                if text.lower()==(self.prefix.lower()+'bans'):
                    txt='[ 暫時黑單 ]'
                    n=1
                    if self.tmpban != []:
                        for x in self.tmpban:
                            txt+=f'\n{n}.{self.bot.getContact(x).displayName}'
                            n+=1
                    else:txt+='\n空'
                    self.bot.sendMessage(to,txt)
                if text.lower()==(self.prefix.lower()+'cbans'):
                    self.tmpban=[]
                    self.bot.sendMessage(to,'清除成功')
                if text.lower()==(self.prefix.lower()+'tgall'):
                    if msg.toType==2:
                        group = self.bot.getGroup(msg.to)
                        w = [x.mid for x in group.members]
                    elif msg.toType==1:
                        group = self.bot.getRoom(msg.to)
                        w = [x.mid for x in group.contacts]
                    k = len(w)//21
                    n=1
                    for a in range(k+1):
                        txt = u''
                        s=2+len(str(n))
                        b=[]
                        if msg.toType ==2:
                            for i in group.members[a*20 : (a+1)*20]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt +=f'【{n}】'+u'@Huan'+'分手沒\n'
                                    n+=1
                                    s += 11+len(str(n))
                        elif msg.toType ==1:
                            for i in group.contacts[a*20 : (a+1)*20]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan'+'分手沒\n'
                                    n+=1
                                    s += 11+len(str(n))
                        self.bot.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                if text.lower()==(self.prefix.lower()+'tgone'):
                    if msg.toType==2:
                        group = self.bot.getGroup(msg.to)
                        w = [x.mid for x in group.members]
                    elif msg.toType==1:
                        group = self.bot.getRoom(msg.to)
                        w = [x.mid for x in group.contacts]
                    k = len(w)//1
                    n=1
                    for a in range(k+1):
                        txt = u''
                        s=2+len(str(n))
                        b=[]
                        if msg.toType ==2:
                            for i in group.members[a*1 : (a+1)*1]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan'+'分手沒'
                                    n+=1
                                    s += 11+len(str(n))
                                    self.bot.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                        elif msg.toType ==1:
                            for i in group.contacts[a*1 : (a+1)*1]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan '+'分手沒'
                                    n+=1
                                    s += 11+len(str(n))
                                    self.bot.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                if text.lower().startswith(self.prefix.lower()+'tgall:'):
                    t=text[(len(self.prefix)+6):]
                    if msg.toType==2:
                        group = self.bot.getGroup(msg.to)
                        w = [x.mid for x in group.members]
                    elif msg.toType==1:
                        group = self.bot.getRoom(msg.to)
                        w = [x.mid for x in group.contacts]
                    k = len(w)//21
                    n=1
                    for a in range(k+1):
                        txt = u''
                        s=2+len(str(n))
                        b=[]
                        if msg.toType ==2:
                            for i in group.members[a*20 : (a+1)*20]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan'+t+'\n'
                                    n+=1
                                    s += 8+len(t)+len(str(n))
                        elif msg.toType ==1:
                            for i in group.contacts[a*20 : (a+1)*20]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan'+t+'\n'
                                    n+=1
                                    s += 8+len(t)+len(str(n))
                        self.bot.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                if text.lower().startswith(self.prefix.lower()+'tgone:'):
                    t=text[(len(self.prefix)+6):]
                    if msg.toType==2:
                        group = self.bot.getGroup(msg.to)
                        w = [x.mid for x in group.members]
                    elif msg.toType==1:
                        group = self.bot.getRoom(msg.to)
                        w = [x.mid for x in group.contacts]
                    k = len(w)//1
                    n=1
                    for a in range(k+1):
                        txt = u''
                        s=2+len(str(n))
                        b=[]
                        if msg.toType ==2:
                            for i in group.members[a*1 : (a+1)*1]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan'+t+'\n'
                                    n+=1
                                    s += 9+len(t)+len(str(n))
                        elif msg.toType ==1:
                            for i in group.contacts[a*1 : (a+1)*1]:
                                if i.mid not in [self.botmid,'uf31469258dd0813534e63ef4b68b4f02']:
                                    b.append({"S":str(s), "E" :str(s+5), "M":i.mid})
                                    txt += f'【{n}】'+u'@Huan'+t+'\n'
                                    s += 9+len(t)+len(str(n))
                                    n+=1
                        self.bot.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                if text.lower().startswith(self.prefix.lower()+'money:'):
                    st=text[(len(self.prefix)+6):]
                    spl=st.split(' ')
                    for x in spl:
                        try:
                            #c=CHRLINE(x,device="ANDROID")
                            c=LINE(st,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.2.6')
                            self.bot.sendMessage(to,'等待驗證中...')
                            self.verify=True
                            self.bot.sendContact(to,x[:33])
                            try:
                                if msg.toType == 2:
                                    g=self.bot.getGroupWithoutMembers(to)
                                    if g.preventedJoinByTicket:
                                        g.preventedJoinByTicket =False
                                        self.bot.updateGroup(g)
                                        c.acceptGroupInvitationByTicket(to,self.bot.reissueGroupTicket(to))
                                        g.preventedJoinByTicket=True
                                        self.bot.updateGroup(g)
                                    else:
                                        c.acceptGroupInvitationByTicket(to,self.bot.reissueGroupTicket(to))
                                    c.sendMessage(to,'錢包')
                                    c.sendMessage(to,'轉帳:12000_@huanxiang',contentMetadata={u'MENTION': json.dumps({'MENTIONEES':{"S":'9', "E" :'19', "M":sender}})})
                            except Exception as e:
                                return self.bot.sendMessage(to,f'不明錯誤\n{e}')
                        except Exception as e:self.bot.sendMessage(to,f'此為無效ST\n{e}')
                if text.lower().startswith(self.prefix.lower()+'tst:'):
                    st=text[(len(self.prefix)+4):]
                    spl=st.split(' ')
                    for x in spl:
                        try:
                            #c=CHRLINE(x,device="ANDROID")
                            c=LINE(st,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.2.6')
                            self.bot.sendMessage(to,'等待驗證中...')
                            self.verify=True
                            self.bot.sendContact(to,x[:33])
                            try:
                                c.findAndAddContactsByMid(self.botmid)
                                cp=c.getProfile()
                                cp.statusMessage='Made By Hx-Team.'
                                cp.displayName='HxTeam.'
                                c.updateProfile(cp)
                                c.updateProfilePicture('cp.jpg')
                                # time.sleep(1)
                                # try:
                                #     c.updateProfileImage('cp.jpg')
                                # except:pass
                                # time.sleep(1)
                                # try:
                                #     c.updateProfileAttribute(16,'Made By Hx-Team.')
                                # except:pass
                                # time.sleep(1)
                                # try:
                                #     c.updateProfileCover('bg.jpg')
                                # except:pass
                            except Exception as e:
                                try:
                                    e.reason
                                    if e.reason == 'request blocked':
                                        self.bot.sendMessage(to,'錯誤 此帳規制中')
                                except:
                                    return self.bot.sendMessage(to,f'不明錯誤\n{e}')
                            c.sendMessage(self.botmid,'test')
                            time.sleep(1)
                            if self.verify == None:
                                self.bot.sendMessage(to,'此為有效ST\n無禁言')
                                self.verify=False
                            elif self.verify == True:
                                self.bot.sendMessage(to,'此為有效ST\n已禁言')
                                self.verify=False
                            elif self.verify == False:self.bot.sendMessage(to,'錯誤')
                        except Exception as e:self.bot.sendMessage(to,f'此為無效ST\n{e}')
                if text.lower()=='getnumber':
                    self.bot.sendMessage(to,'嘗試創建中 請稍後')
                    locale='7'
                    ctced = locale
                    req=requests.get('http://sms-activate.ru/stubs/handler_api.php', params={'api_key': 'A4c6708A391cb2488e9fcc163875e2cd','action': 'getNumber','service': 'me','country': ctced})
                    req=req.text
                    print(req)
                    if 'ACCESS_NUMBER' in req:
                        try:
                            req1 = req.split(':')
                            ordid = req1[1]
                            ordphone = req1[2]
                            if '+'in ordphone:
                                ordphone = ordphone.split('+')
                            phone = ordphone
                            n=self.bot.relatedMessage(to,str(phone),msg.id).id
                            wait["orderid"][ordid] = True
                            def getcode1(orderId):
                                counter = 0
                                while True:
                                    time.sleep(1)
                                    counter += 1
                                    if counter >= 1200:
                                        raise Exception('timeout')
                                    if orderId in wait['orderid']:
                                        response = requests.get('http://sms-activate.ru/stubs/handler_api.php', params={'api_key': 'A4c6708A391cb2488e9fcc163875e2cd','action': 'getStatus','id': orderId}).text
                                        if 'STATUS_OK' in response:
                                            break
                                    else:
                                        raise Exception('release')
                                return response.split(':')[1]
                            try:
                                requests.get('http://sms-activate.ru/stubs/handler_api.php', params={'api_key': 'A4c6708A391cb2488e9fcc163875e2cd','action': 'setStatus','status': '1','id': ordid})
                                pin = getcode1(ordid)
                                print(f'Pin Code:{pin}')
                                self.bot.relatedMessage(to,str(pin),n)
                            except Exception as e:self.bot.sendMessage(to,str(e))
                        except Exception as e:self.bot.sendMessage(to,str(e))
                    elif 'NO_NUMBERS' == req:
                        self.bot.relatedMessage(to,"該國家已無空號",msg_id)
                    elif 'NO_BALANCE' == req:
                        self.bot.relatedMessage(to,"系統餘額已經用盡",msg_id)
                    else:
                        self.bot.relatedMessage(to,"號碼取得失敗",msg_id)
                if text.lower().startswith(self.prefix.lower()+'autocreate:'):
                    if text[(len(self.prefix)+11):] == '':return self.bot.sendMessage(to,'無效的區域')
                    else:locale=text[(len(self.prefix)+11):].upper()
                    self.bot.sendMessage(to,'嘗試創建中 請稍後')
                    param = {'myPid':'2743','locale':locale,'apikey':'bb93ed5e545204d8c0ff3c430fd5f566'}
                    step1=requests.get('http://www.jindousms.com/public/sms/getNumber',params=param).json()
                    if step1['code'] == -1 and 'Insufficient balance, please recharge.' in step1['data']:
                        self.bot.relatedMessage(to,'機器餘額不足',msg.id)
                    elif step1['code'] == -1:
                        self.bot.relatedMessage(to,f'錯誤:\n{step1["data"]}',msg.id)
                    print(step1)
                    orderId=step1["data"]["orderId"]
                    phone = step1["data"]["number"]
                    noget = 0
                    w = 0
                    #====================================
                    print('導入SHA DEF')
                    def getSHA256Sum(*args):
                        instance = hashlib.sha256()
                        for arg in args:
                            if isinstance(arg, str):arg = arg.encode()
                            instance.update(arg)
                        return instance.digest()
                    print('導入Get issued')
                    def get_issued_at() -> bytes:return base64.b64encode(f"iat: {int(time.time()) * 60}\n".encode("utf-8")) + b"."
                    print('導入get digest')
                    def get_digest(key: bytes, iat: bytes) -> bytes:return base64.b64encode(hmac.new(key, iat, hashlib.sha1).digest())
                    print('導入create token')
                    def create_token(auth_key: str) -> str:
                        mid, key = auth_key.partition(":")[::2]
                        key = base64.b64decode(key.encode("utf-8"))
                        iat = get_issued_at()
                        digest = get_digest(key, iat).decode("utf-8")
                        iat = iat.decode("utf-8")
                        return mid+":"+iat+"."+digest
                    UPDATE_NAME = True
                    TURN_OFF_E2EE = True
                    keyword='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                    k=[x for x in keyword]
                    rnname=''
                    rnpwd=''
                    print('處理隨機帳密')
                    for x in range(random.randint(10,20)):
                        rnname+=str(random.choice(k))
                    for x in range(random.randint(10,20)):
                        rnpwd+=str(random.choice(k))
                    DISPLAY_NAME = f"{rnname}"
                    cl = CHRLINE(noLogin=True)
                    print(f'已選用隨機名:{DISPLAY_NAME}')
                    proxies=random.choice(proxy)
                    print('開始處理加密')
                    session = cl.openPrimarySession(proxies)
                    private_key = Curve25519.generatePrivateKey(os.urandom(32))
                    public_key = Curve25519.generatePublicKey(private_key)
                    nonce = os.urandom(16)
                    b64_private_key = base64.b64encode(private_key)
                    b64_public_key = base64.b64encode(public_key)
                    b64_nonce = base64.b64encode(nonce)
                    info = cl.getCountryInfo(session)
                    region =locale#"ID"
                    device_list=[
                        '1100',
                        '1105',
                        '1107',
                        '1201',
                        '1206',
                        '3000',
                        'Mirror3',
                        '3005',
                        '3007',
                        '3008',
                        'A11',
                        'A11w',
                        'CPH1837',
                        'A33',
                        'CPH1803',
                        'CPH1853',
                        'CPH1605',
                        'CPH1609',
                        'CPH1705',
                        'CPH1801',
                        'CPH1725',
                        'CPH1717',
                        'CPH1613'
                    ]
                    device=random.choice(device_list)
                    print(f'隨機抽取機型名:{device}')
                    phone2 = cl.getPhoneVerifMethod(session, phone, region,deviceModel=device,proxies=proxies)[3]
                    sendPin = cl.sendPinCodeForPhone(session, phone, region,deviceModel=device,proxies=proxies)
                    wait["orderid"][step1["data"]["orderId"]] = [sender]
                    #====================================
                    v=False
                    print('開始收驗證')
                    for x in range(1,121):
                        try:
                            l="http://www.jindousms.com/public/sms/getCode"
                            pam = {
                                "orderId":orderId,
                                'apikey':'bb93ed5e545204d8c0ff3c430fd5f566'
                            }
                            try:
                                if orderId in wait["orderid"]:
                                    w+=1;print("取得{}次驗證 商品ID:{}".format(w,orderId))
                                    l = json.loads((requests.get(l,params=pam)).text)
                                    if l["code"] == 1:
                                        ver=l["data"]["code"].replace('+','')
                                        pin = ver
                                        verify = cl.verifyPhone(session, phone, region, pin,deviceModel=device,proxies=proxies)
                                        if 'error' in verify:
                                            if verify['error']['code'] == 5:
                                                self.bot.sendMessage(to,'真人驗證失敗');v=True
                                                self.bot.sendMessage(to,'Metadata為:')
                                                self.bot.sendMessage(to,str(verify['error']['metadata'][11][1]))
                                                self.bot.sendMessage(to,str(verify['error']['metadata'][11][2]))
                                                break
                                                # hv = HumanVerif(verify['error']['metadata'][11][1], verify['error']['metadata'][11][2])
                                                # RetryReq(session, hv)
                                        cl.validateProfile(session, DISPLAY_NAME,proxies=proxies)
                                        exchangeEncryptionKey  = cl.exchangeEncryptionKey(session, b64_public_key.decode(), b64_nonce.decode(), 1,proxies=proxies)
                                        exc_key                = base64.b64decode(exchangeEncryptionKey[1])
                                        exc_nonce              = base64.b64decode(exchangeEncryptionKey[2])
                                        sign                   = Curve25519.calculateAgreement(private_key, exc_key)
                                        password               = rnpwd
                                        master_key             = getSHA256Sum(b'master_key', sign, nonce, exc_nonce)
                                        aes_key                = getSHA256Sum(b'aes_key', master_key)
                                        hmac_key               = getSHA256Sum(b'hmac_key', master_key)
                                        e1                     = AES.new(aes_key[:16], AES.MODE_CBC, aes_key[16:32])
                                        doFinal                = e1.encrypt(pad(password.encode(), 16))
                                        hmacd                  = hmac.new(hmac_key,msg=doFinal,digestmod=hashlib.sha256).digest()
                                        encPwd                 = base64.b64encode(doFinal + hmacd).decode()
                                        setPwd                 = cl.setPassword(session, encPwd, 1,proxies=proxies)
                                        if 'error' in setPwd:
                                            doFinal                = e1.encrypt(pad('qwer8520'.encode(), 16))
                                            hmacd                  = hmac.new(hmac_key,msg=doFinal,digestmod=hashlib.sha256).digest()
                                            encPwd                 = base64.b64encode(doFinal + hmacd).decode()
                                            setPwd = cl.setPassword(session, encPwd, 1,proxies=proxies)
                                        register               = cl.registerPrimaryUsingPhone(session,proxies=proxies)
                                        authKey                = register[1]
                                        authToken              = create_token(authKey)
                                        self.bot.sendMessage(to,f'自動創建結果:\nAuthkey:{authKey}\nST:{authToken}')
                                        self.bot.sendContact(to,authKey[:33])
                                        cl=LINE(authToken,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.11.1')#ANDROIDLITE 2.16.0 Android OS 11.2.6
                                        # cl = CHRLINE(x,device="ANDROID")
                                        if msg.toType == 2:
                                            g=self.bot.getGroupWithoutMembers(to)
                                            if g.preventedJoinByTicket:
                                                g.preventedJoinByTicket =False
                                                self.bot.updateGroup(g)
                                                cl.acceptGroupInvitationByTicket(to,self.bot.reissueGroupTicket(to))
                                                g.preventedJoinByTicket=True
                                                self.bot.updateGroup(g)
                                            else:
                                                cl.acceptGroupInvitationByTicket(to,self.bot.reissueGroupTicket(to))
                                            
                                        # if UPDATE_NAME:
                                        #     cl.updateProfileAttribute(2, DISPLAY_NAME)
                                        # if TURN_OFF_E2EE:
                                        #     sett = cl.getSettingsAttributes2([33])
                                        #     sett[61] = False
                                        #     cl.updateSettingsAttributes2(sett, [33])
                                        cl.findAndAddContactsByMid(sender)
                                        # cl.updateProfileImage('cp.jpg')
                                        # cl.updateProfileCover('bg.jpg')
                                        # cl.updateProfileAttribute(16,f'Made By Hx-Team.\n{rnname}')
                                        cl.sendMessage(sender,f'創建成功\n我的ST為:{authToken}')
                                        del wait["orderid"][orderId]
                                        noget = 1
                                        break
                                else:
                                    if v:
                                        self.bot.sendMessage(to,'取得手機驗證失敗')
                                    noget = 2
                                    break
                            except Exception as e:
                                self.bot.sendMessage(to,f'系統出錯:\n{e}')
                            time.sleep(5)
                        except:
                            break
                    if noget == 0:
                        del wait["orderid"][orderId]
                        if v:
                            self.bot.sendMessage(to,'取得手機驗證失敗')
                if text.lower().startswith(self.prefix.lower()+'autocreate2:'):
                    if text[(len(self.prefix)+12):] == '':return self.bot.sendMessage(to,'無效的區域')
                    else:locale=text[(len(self.prefix)+12):].upper()
                    self.bot.sendMessage(to,'嘗試創建中 請稍後')
                    ctced = locale
                    req= requests.get('http://sms-activate.ru/stubs/handler_api.php', params={'api_key': 'A4c6708A391cb2488e9fcc163875e2cd','action': 'getNumber','service': 'me','country': ctced})
                    req=req.text
                    print(req)
                    if 'ACCESS_NUMBER' in req:
                        try:
                            proxies=random.choice(proxy)
                            req1 = req.split(':')
                            ordid = req1[1]
                            ordphone = req1[2]
                            if '+'in ordphone:
                                ordphone = ordphone.split('+')
                            phone = ordphone
                            wait["orderid"][ordid] = True
                            def getSHA256Sum(*args):
                                instance = hashlib.sha256()
                                for arg in args:
                                    if isinstance(arg, str):arg = arg.encode()
                                    instance.update(arg)
                                return instance.digest()
                            def get_issued_at() -> bytes:return base64.b64encode(f"iat: {int(time.time()) * 60}\n".encode("utf-8")) + b"."
                            def get_digest(key: bytes, iat: bytes) -> bytes:return base64.b64encode(hmac.new(key, iat, hashlib.sha1).digest())
                            def create_token(auth_key: str) -> str:
                                mid, key = auth_key.partition(":")[::2]
                                key = base64.b64decode(key.encode("utf-8"))
                                iat = get_issued_at()
                                digest = get_digest(key, iat).decode("utf-8")
                                iat = iat.decode("utf-8")
                                return mid+":"+iat+"."+digest
                            UPDATE_NAME = True
                            TURN_OFF_E2EE = True
                            keyword='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                            k=[x for x in keyword]
                            rnname=''
                            rnpwd=''
                            for x in range(random.randint(10,20)):
                                rnname+=str(random.choice(k))
                            for x in range(random.randint(10,20)):
                                rnpwd+=str(random.choice(k))
                            DISPLAY_NAME = f"{rnname}"
                            cl = CHRLINE(noLogin=True)
                            print(f'已選用隨機名:{DISPLAY_NAME}')
                            session = cl.openPrimarySession(proxies)
                            print(session)
                            private_key = Curve25519.generatePrivateKey(os.urandom(32))
                            public_key = Curve25519.generatePublicKey(private_key)
                            nonce = os.urandom(16)
                            b64_private_key = base64.b64encode(private_key)
                            b64_public_key = base64.b64encode(public_key)
                            b64_nonce = base64.b64encode(nonce)
                            info = cl.getCountryInfo(session)
                            if locale == '6':
                                region='ID'
                            device_list=[
                                '1100',
                                '1105',
                                '1107',
                                '1201',
                                '1206',
                                '3000',
                                'Mirror3',
                                '3005',
                                '3007',
                                '3008',
                                'A11',
                                'A11w',
                                'CPH1837',
                                'A33',
                                'CPH1803',
                                'CPH1853',
                                'CPH1605',
                                'CPH1609',
                                'CPH1705',
                                'CPH1801',
                                'CPH1725',
                                'CPH1717',
                                'CPH1613'
                            ]
                            device=random.choice(device_list)
                            print(f'隨機抽取機型名:{device}')
                            phone2 = cl.getPhoneVerifMethodV2(session, phone, region,deviceModel=device,proxies=proxies)
                            sendPin = cl.requestToSendPhonePinCode(session, phone, region, phone2[1][0],proxies=proxies)
                            def getcode1(orderId):
                                counter = 0
                                while True:
                                    time.sleep(1)
                                    counter += 1
                                    if counter >= 1200:
                                        raise Exception('timeout')
                                    if orderId in wait['orderid']:
                                        response = requests.get('http://sms-activate.ru/stubs/handler_api.php', params={'api_key': 'A4c6708A391cb2488e9fcc163875e2cd','action': 'getStatus','id': orderId}).text
                                        if 'STATUS_OK' in response:
                                            break
                                    else:
                                        raise Exception('release')
                                return response.split(':')[1]
                            try:
                                requests.get('http://sms-activate.ru/stubs/handler_api.php', params={'api_key': 'A4c6708A391cb2488e9fcc163875e2cd','action': 'setStatus','status': '1','id': ordid})
                                pin = getcode1(ordid)
                                print(f'Pin Code:{pin}')
                                verify = cl.verifyPhonePinCode(session, phone, region, pin,proxies=proxies)
                                print('verify成功')
                                if 'error' in verify:
                                    if verify['error']['code'] == 5:
                                        self.bot.sendMessage(to,'真人驗證失敗');v=True
                                        self.bot.sendMessage(to,'Metadata為:')
                                        self.bot.sendMessage(to,str(verify['error']['metadata'][11][1]))
                                        self.bot.sendMessage(to,str(verify['error']['metadata'][11][2]))
                                cl.validateProfile(session, DISPLAY_NAME,proxies=proxies)
                                print('valid成功')
                                exchangeEncryptionKey  = cl.exchangeEncryptionKey(session, b64_public_key.decode(), b64_nonce.decode(), 1,proxies=proxies)
                                print('exchange成功')
                                exc_key                = base64.b64decode(exchangeEncryptionKey[1])
                                exc_nonce              = base64.b64decode(exchangeEncryptionKey[2])
                                sign                   = Curve25519.calculateAgreement(private_key, exc_key)
                                password               = rnpwd
                                master_key             = getSHA256Sum(b'master_key', sign, nonce, exc_nonce)
                                aes_key                = getSHA256Sum(b'aes_key', master_key)
                                hmac_key               = getSHA256Sum(b'hmac_key', master_key)
                                e1                     = AES.new(aes_key[:16], AES.MODE_CBC, aes_key[16:32])
                                doFinal                = e1.encrypt(pad(password.encode(), 16))
                                hmacd                  = hmac.new(hmac_key,msg=doFinal,digestmod=hashlib.sha256).digest()
                                encPwd                 = base64.b64encode(doFinal + hmacd).decode()
                                setPwd                 = cl.setPassword(session, encPwd, 1,proxies=proxies)
                                print('setPwd成功')
                                if 'error' in setPwd:
                                    doFinal                = e1.encrypt(pad('qwer8520'.encode(), 16))
                                    hmacd                  = hmac.new(hmac_key,msg=doFinal,digestmod=hashlib.sha256).digest()
                                    encPwd                 = base64.b64encode(doFinal + hmacd).decode()
                                    setPwd = cl.setPassword(session, encPwd, 1,proxies=proxies)
                                register               = cl.registerPrimaryWithTokenV3(session,proxies=proxies)
                                print('register成功')
                                authKey                = register[1]
                                tokenV3IssueResult = register[2]
                                mid = register[3]
                                primaryToken = create_token(authKey)
                                self.bot.sendMessage(to,f'自動創建結果:\nAuthkey:{authKey}\nST:{primaryToken}')
                                self.bot.sendContact(to,authKey[:33])
                                cl = CHRLINE(primaryToken, device="ANDROID")#ANDROIDLITE 2.16.0 Android OS 11.2.6
                                cl.updateProfileAttribute(2, DISPLAY_NAME)
                                #cp=cl.getProfile()
                                #cp.statusMessage='Made By Hx-Team.'
                                #cp.displayName=DISPLAY_NAME
                                cl.updateProfile(cp)
                                cl.updateProfilePicture('cp.jpg')
                                g=self.bot.getGroupWithoutMembers(to)
                                if g.preventedJoinByTicket:
                                    g.preventedJoinByTicket =False
                                    self.bot.updateGroup(g)
                                    cl.acceptGroupInvitationByTicket(to,self.bot.reissueGroupTicket(to))
                                    g.preventedJoinByTicket=True
                                    self.bot.updateGroup(g)
                                else:
                                    cl.acceptGroupInvitationByTicket(to,self.bot.reissueGroupTicket(to))
                                cl.sendMessage(to,f'創建成功\n我的ST為:{authToken}')
                                cl.findAndAddContactsByMid(sender)
                                cl.sendMessage(sender,f'創建成功\n我的ST為:{authToken}')
                                del wait["orderid"][ordid]
                            except Exception as e:
                                self.bot.relatedMessage(to,"自動創建失敗\n"+str(e) ,msg_id)
                                del wait["orderid"][ordid]
                        except Exception as error:self.bot.sendMessage(to,str(error))
                    elif 'NO_NUMBERS' == req:
                        self.bot.relatedMessage(to,"該國家已無空號",msg_id)
                    elif 'NO_BALANCE' == req:
                        self.bot.relatedMessage(to,"系統餘額已經用盡",msg_id)
                    else:
                        self.bot.relatedMessage(to,"號碼取得失敗",msg_id)
                if text.lower()==(self.prefix.lower()+'rebk'):
                    self.bot.relatedMessage(to,'清除中...',msg.id)
                    s=time.time()
                    fileDir = r"data/file/"
                    q=0
                    size=0
                    w = [_ for _ in os.listdir(fileDir)]
                    for x in w:
                        size+=int(os.path.getsize("data/file/"+x))
                        os.remove("data/file/"+x)
                        q+=1
                    fileDir = r"data/sound/"
                    fileExt = r".mp3"
                    w = [_ for _ in os.listdir(fileDir) if _.endswith(fileExt)]
                    for x in w:
                        size+=int(os.path.getsize("data/sound/"+x))
                        os.remove("data/sound/"+x)
                        q+=1
                    fileDir = r"data/video/"
                    fileExt = r".mp4"
                    w = [_ for _ in os.listdir(fileDir) if _.endswith(fileExt)]
                    for x in w:
                        size+=int(os.path.getsize("data/video/"+x))
                        os.remove("data/video/"+x)
                        q+=1
                    fileDir = r"data/image/"
                    fileExt = r".jpg"
                    w = [_ for _ in os.listdir(fileDir) if _.endswith(fileExt)]
                    for x in w:
                        size+=int(os.path.getsize("data/image/"+x))
                        os.remove("data/image/"+x)
                        q+=1
                    fileExt = r".gif"
                    w = [_ for _ in os.listdir(fileDir) if _.endswith(fileExt)]
                    for x in w:
                        size+=int(os.path.getsize("data/image/"+x))
                        os.remove("data/image/"+x)
                        q+=1
                    if size >=1000:
                        mathsize=size/1000
                        kbmb='Kb'
                    elif size>= 1000000:
                        mathsize=size/1000000
                        kbmb='Gb'
                    else:
                        mathsize=size
                        kbmb='Mb'
                    self.bot.relatedMessage(to,f"清除完畢\n共{q}個檔案\n耗時{str(time.time() - s)}\n檔案總大小:{mathsize}{kbmb}",msg.id)
                if text.lower().startswith(self.prefix.lower()+'getst:'):
                    from bs4 import BeautifulSoup
                    page=text[(len(self.prefix)+6):]
                    url=f'https://store.line.me/stickers-premium/showcase/top/zh-Hant?page={page}'
                    soup=BeautifulSoup(requests.get(url).text,'html.parser')
                    w=soup.find_all('li')
                    lis=[]
                    for x in w:
                        for r in x.find_all('img'):
                            if 'https://stickershop.line-scdn.net/stickershop/v1/product/' not in r['src']:continue
                            step1=r['src'].replace('https://stickershop.line-scdn.net/stickershop/v1/product/','')
                            step2=step1.replace('/LINEStorePC/thumbnail_shop.png;compress=true','')
                            lis.append(step2)
                    url='https://store.line.me/stickers-premium/addProductToSubscriptionSlot/zh-Hant'
                    header={
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'cookie': 'XSRF-TOKEN=16907004-a60e-4552-b11c-93b0f28cc8ea; uu=zDQXDCGPBKR4wf8jnIPeX8nJoMyoFuhDT0SwKwEmHQINoA3mTKBKIKvvlV6ZR31u; fs=%7B%221%22%3A%7B%22impressed%22%3Afalse%7D%2C%222%22%3A%7B%22impressed%22%3Afalse%7D%2C%223%22%3A%7B%22impressed%22%3Afalse%7D%2C%224%22%3A%7B%22impressed%22%3Afalse%7D%7D; _ga=GA1.2.1075837375.1610877250; _ldbrbid=lo__xOENoy9VrvzOMG51ggM19WUEAFqlJWRIdDkZO3WxRs4; oa=UNSPECIFIED; __gads=ID=c1df03ec38648dfc:T=1619093903:S=ALNI_MZFcjNMobX500rmJVKWyi68QdAc_A; __is_login_sso=1; display_lang=zh-Hant; GLOBAL_PREMIUM_POPUP_TW=1; ss=Bf4jL9MjtXJujeLjiR7fyjfUo10UqVNFgVVyLdJ6zNcZP96G95CHZm28HegIPfg0P9ry6VNVK07XPlrA5SH3vfh5dQyuaRRMWrLx:1345d:17a47a8ec60; lastReserveIsPresent=false',
                        'sec-ch-ua': '"Chromium";v="90", "Opera GX";v="76", ";Not A Brand";v="99"',
                        'sec-ch-ua-mobile': '?0',
                        'sec-fetch-dest': 'empty',
                        'sec-fetch-mode': 'cors',
                        'sec-fetch-site': 'same-origin',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 OPR/76.0.4017.208',
                        'x-requested-with':'XMLHttpRequest'
                    }
                    self.bot.relatedMessage(to,'請稍等',msg.id)
                    txt='[ Auto Grab Sticker ]'
                    for x in lis:
                        data={'packageId':int(x)}
                        r=requests.post(url,data=data,headers=header).status_code
                        txt+=f'\nID:{x}\n{"    取得成功" if str(r) == "200" else "    獲取失敗(貼圖包ID不支持超值方案或已獲取)"}'
                    self.bot.relatedMessage(to,txt,msg.id)
                if text.lower().startswith(self.prefix.lower()+'getst2:'):
                    from bs4 import BeautifulSoup
                    ids=text[(len(self.prefix)+7):]
                    url=f'https://store.line.me/stickershop/author/{ids}/zh-Hant'
                    soup=BeautifulSoup(requests.get(url).text,'html.parser')
                    w=soup.find_all('li')
                    lis=[]
                    for x in w:
                        for r in x.find_all('img'):
                            if 'https://stickershop.line-scdn.net/stickershop/v1/product/' not in r['src']:continue
                            step1=r['src'].replace('https://stickershop.line-scdn.net/stickershop/v1/product/','')
                            step2=step1.replace('/LINEStorePC/thumbnail_shop.png;compress=true','')
                            lis.append(step2)
                    url='https://store.line.me/stickers-premium/addProductToSubscriptionSlot/zh-Hant'
                    header={
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'cookie': 'XSRF-TOKEN=16907004-a60e-4552-b11c-93b0f28cc8ea; uu=zDQXDCGPBKR4wf8jnIPeX8nJoMyoFuhDT0SwKwEmHQINoA3mTKBKIKvvlV6ZR31u; fs=%7B%221%22%3A%7B%22impressed%22%3Afalse%7D%2C%222%22%3A%7B%22impressed%22%3Afalse%7D%2C%223%22%3A%7B%22impressed%22%3Afalse%7D%2C%224%22%3A%7B%22impressed%22%3Afalse%7D%7D; _ga=GA1.2.1075837375.1610877250; _ldbrbid=lo__xOENoy9VrvzOMG51ggM19WUEAFqlJWRIdDkZO3WxRs4; oa=UNSPECIFIED; __gads=ID=c1df03ec38648dfc:T=1619093903:S=ALNI_MZFcjNMobX500rmJVKWyi68QdAc_A; __is_login_sso=1; display_lang=zh-Hant; GLOBAL_PREMIUM_POPUP_TW=1; ss=Bf4jL9MjtXJujeLjiR7fyjfUo10UqVNFgVVyLdJ6zNcZP96G95CHZm28HegIPfg0P9ry6VNVK07XPlrA5SH3vfh5dQyuaRRMWrLx:1345d:17a47a8ec60; lastReserveIsPresent=false; lastReserveIsPresent=false',
                        'sec-ch-ua': '"Chromium";v="90", "Opera GX";v="76", ";Not A Brand";v="99"',
                        'sec-ch-ua-mobile': '?0',
                        'sec-fetch-dest': 'empty',
                        'sec-fetch-mode': 'cors',
                        'sec-fetch-site': 'same-origin',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 OPR/76.0.4017.208',
                        'x-requested-with':'XMLHttpRequest'
                    }
                    self.bot.relatedMessage(to,'請稍等',msg.id)
                    txt='[ Auto Grab Sticker ]'
                    for x in lis:
                        data={'packageId':int(x)}
                        r=requests.post(url,data=data,headers=header).status_code
                        txt+=f'\nID:{x}\n{"    取得成功" if str(r) == "200" else "    獲取失敗(貼圖包ID不支持超值方案或已獲取)"}'
                    self.bot.relatedMessage(to,txt,msg.id)
                if text.lower().startswith(self.prefix.lower()+'mid '):
                    targets = []
                    n = 0
                    if not msg.contentMetadata["MENTION"]:return
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        n+=1
                        targets.append(f'{n}.名稱:{self.bot.getContact(x["M"]).displayName}')
                        targets.append('  '+x["M"])
                    txt='[ Mid ]\n'
                    txt+='\n'.join(targets)
                    self.bot.relatedMessage(to,txt,msg.id)
                if text.lower() == self.prefix.lower()+'mymid':
                    self.bot.relatedMessage(to,sender,msg.id)
                if text.lower().startswith('set:'):
                    if text[4:] == 'ac':
                        if self.settings['autochange'] == True:
                            self.settings['autochange'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['autochange'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'td':
                        if self.settings['token'] == True:
                            self.settings['token'] = False
                            self.bot.relatedMessage(to,'更改成功 => 加載線呈',msg.id)
                        else:
                            self.settings['token'] = True
                            self.bot.relatedMessage(to,'更改成功 => 預備線呈',msg.id)
                    if text[4:] == 'ai':
                        if self.settings['antiinv'] == True:
                            self.settings['antiinv'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['antiinv'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'aj':
                        if self.settings['autojoin'] == True:
                            self.settings['autojoin'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['autojoin'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'print':
                        if self.settings['print'] == True:
                            self.settings['print'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['print'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'tr':
                        if self.settings['tagreply'] == True:
                            self.settings['tagreply'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['tagreply'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'protect':
                        if self.settings['protect'] == True:
                            self.settings['protect'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['protect'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'sb':
                        if self.settings['stickerkick'] == True:
                            self.settings['stickerkick'] = False
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['stickerkick'] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:] == 'gamble':
                        if to in self.isgamble:
                            del self.isgamble[to]
                            self.bot.sendMessage(to,'關閉成功')
                        else:
                            self.bot.relatedMessage(to,'18拉',msg.id)
                            self.dm[to]=True
                            self.isgamble[to]={'money':None,'bs':random.choice(['大','小'])}
                            time.sleep(1)
                            self.bot.relatedMessage(to,'錢包',msg.id)
                    if text[4:] == 'gp':
                        if to in self.settings['ProtectGroups']:
                            del self.settings['ProtectGroups'][to]
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.settings['ProtectGroups'][to] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                            if len(self.tokens) <50:
                                self.bot.relatedMessage(to,'檢測到線程數不足\n自動加載中...',msg.id)
                                tasks=[]
                                def run():self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                for x in range(50):
                                    t=threading.Thread(target=run)
                                    tasks.append(t)
                                for x in tasks:x.start()
                                for x in tasks:x.join()
                                self.bot.relatedMessage(to,'自動加載完畢!\n已自動幫您加載50線程',msg.id)
                            self.bot.relatedMessage(to,'機器將自動掃單群黑單..',msg.id)
                            t=threading.Thread(target=self.kban,args=(to,))
                            t.start()
                            t.join()
                            self.bot.relatedMessage(to,'掃黑完畢!',msg.id)
                    if text[4:] == 'jk':
                        if to in self.joinkick:
                            del self.joinkick[to]
                            self.bot.relatedMessage(to,'更改成功 => 關閉',msg.id)
                        else:
                            self.joinkick[to] = True
                            self.bot.relatedMessage(to,'更改成功 => 開啟',msg.id)
                    if text[4:].startswith('prefix:'):
                        self.settings['prefix'] = text[11:]
                        self.prefix = text[11:]
                        self.bot.relatedMessage(to,f'更改成功 => {text[11:] if self.prefix != "" else "無"}',msg.id)
                    json.dump(self.settings,codecs.open('json/settings.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
                if text.lower().startswith(self.prefix.lower()+'load:'):
                    try:num=int(text[(len(self.prefix)+5):])
                    except:self.bot.relatedMessage(to,'錯誤',msg.id)
                    def loadtd():return self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                    self.bot.relatedMessage(to,'加載中...',msg.id)
                    print('加載線呈中...')
                    t1=time.time()
                    for x in tqdm(range(num)):threading.Thread(target=loadtd).start()
                    t2=time.time()
                    print('加載完畢!')
                    self.bot.relatedMessage(to,f'加載完成\n耗時{t2 - t1}秒\n平均線呈耗時{((t2 - t1)/num)}秒',msg.id)
                if text.lower().startswith(self.prefix.lower()+'load2:'):
                    try:num=int(text[(len(self.prefix)+6):])
                    except:self.bot.relatedMessage(to,'錯誤',msg.id)
                    self.bot.relatedMessage(to,'加載中...(使用CPython)',msg.id)
                    t1=time.time()
                    tdload.load(self.tokens,self.bot.authToken,LINE,num)
                    t2=time.time()
                    self.bot.relatedMessage(to,f'加載完成\n耗時{t2 - t1}秒\n平均線呈耗時{((t2 - t1)/num)}秒',msg.id)
                if text.lower() == self.prefix.lower()+"getmail":
                    def get():
                        box=mailbox()
                        self.bot.relatedMessage(to,box.email,msg.id)
                        result=json.loads(box.next()[1:])
                        self.bot.relatedMessage(to,str("發送者:"+result["from_hdr"]+"\n發送時間:"+result["received"]+"\n信箱主旨:"+result["subject"]+"\n信箱內容:"+result["text"]),msg.id)
                    threading.Thread(target=get).start()
                if text.lower() == self.prefix.lower()+'ren':
                    with open('txt/lt','r') as f:
                        txt=f.read()
                        if txt != 'None':secs = time.time() - int(float(txt))
                        else:return self.bot.relatedMessage(to,'無法讀取\n請重新使用帳密登入',msg.id)
                    mins, secs = divmod(secs,60)
                    hours, mins = divmod(mins,60)
                    days, hours = divmod(hours, 24)
                    self.bot.relatedMessage(to,'機器運行時間如下:\n%02d天\n%02d小時\n%02d分鐘\n%02d秒'%(days,hours,mins,secs),msg.id)
                if text == 'tdk':
                    if msg.toType != 2:return
                    group=self.bot.getGroup(to)
                    invs=[]
                    mems=[]
                    # try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    # except Exception as e:
                    #     if e.reason == "request blocked":return self.bot.relatedMessage(to,'你已經失去了所有 還想幹嘛',msg.id)
                    # with open('txt/kc','r') as f:
                    #     num=json.loads(f.read())['mem']
                    #     if len(group.members) >=(150-int(num)):
                    #         return self.bot.relatedMessage(to,'你腳已經快骨折了 你不用休息嗎???',msg.id)
                    # if len(group.members) == 1:return self.bot.relatedMessage(to,'當你發現這世界只有你時\n時間已晚',msg.id)
                    if group.invitee:
                        for x in group.invitee:invs.append(x.mid)
                    for x in group.members:mems.append(x.mid)
                    self.joinkick[to] = True
                    tk.proces(mems,invs,to,LINE,self.bot.authToken,self.botmid,self.admin)
                if text == 'FuckThisGroup':
                    if msg.toType != 2:return
                    group=self.bot.getGroup(to)
                    tmp=[]
                    task=[]
                    task2=[]
                    try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    except Exception as e:
                        if e.reason == "request blocked":return self.bot.relatedMessage(to,'你已經失去了所有 還想幹嘛',msg.id)
                    with open('txt/kc','r') as f:
                        num=json.loads(f.read())['mem']
                        if len(group.members) >=(150-int(num)):
                            return self.bot.relatedMessage(to,'你腳已經快骨折了 你不用休息嗎???',msg.id)
                    if len(group.members) == 1:return self.bot.relatedMessage(to,'當你發現這世界只有你時\n時間已晚',msg.id)
                    self.joinkick[to] = True
                    if self.settings["token"] == True:
                        if len(self.tokens) < len(group.members):
                            for x in range(len(group.members)-1):
                                self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                tmp=self.tokens
                        else:tmp=self.tokens
                    else:
                        for x in range(len(group.members)-1):tmp.append(LINE(self.bot.authToken,appName=self.device))
                    n=0
                    targets=[x.mid for x in group.members]
                    
                    for x in targets:
                        if x.mid != self.botmid and x.mid not in self.admin:
                            t=threading.Thread(target=tmp[int(n)].kickoutFromGroup,args=(to,[x.mid]))
                            n+=1
                            task.append(t)
                            tz = pytz.timezone("Asia/Taipei")				
                            timeNow = datetime.datetime.now(tz=tz)
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            with open('txt/kc','r') as f:
                                js=json.loads(f.read())
                                f.close()
                            with open('txt/kc','w') as f:
                                js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                                js["mem"]+=1
                                f.write(str(json.dumps(js)))
                                f.close()
                    self.bot.sendMessage(to,'掰掰各位 幻想降臨\n歡迎追蹤哀居 huan.0317.dev')
                    group.name = '幻想降臨~'
                    self.bot.updateGroup(group)
                    for x in task:x.start()
                    if group.invitee:
                        if len(group.invitee)<=30:
                            for x in group.invitee:self.bot.cancelGroupInvitation(to,[x.mid])
                        else:self.bot.inviteIntoGroup(to,['ud1602508aeb748635a9ebe468d6064d1'])
                if text == self.prefix.lower()+'清非官':
                    gs = self.bot.getGroup(op.message.to)
                    targets = []
                    task=[]
                    try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    except Exception as e:
                        if e.reason == "request blocked":return self.bot.relatedMessage(to,'你已經失去了所有 還想幹嘛',msg.id)
                    for g in gs.members:
                        if g.capableBuddy==True:targets.append(g.mid)
                    with open('txt/kc','r') as f:
                        num=json.loads(f.read())['mem']
                        if len(targets) >=(150-int(num)):return self.bot.relatedMessage(to,'你腳已經快骨折了 你不用休息嗎???',msg.id)
                    if targets == []:pass
                    else:
                        if self.settings["token"] == True:
                            if len(self.tokens) < len(targets):
                                for x in range(len(targets)):
                                    self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                    tmp=self.tokens
                            else:tmp=self.tokens
                        else:
                            for x in range(len(targets)):tmp.append(LINE(self.bot.authToken,appName=self.device))
                        n=0
                        
                        for x in targets:
                            if x not in self.botmid:
                                t=threading.Thread(target=tmp[int(n)].kickoutFromGroup,args=(to,[x]))
                                n+=1
                                task.append(t)
                                tz = pytz.timezone("Asia/Taipei")				
                                timeNow = datetime.datetime.now(tz=tz)
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                with open('txt/kc','r') as f:
                                    js=json.loads(f.read())
                                    f.close()
                                with open('txt/kc','w') as f:
                                    js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                                    js["mem"]+=1
                                    f.write(str(json.dumps(js)))
                                    f.close()
                        for x in task:x.start()
                if text == self.prefix.lower()+'定名':return self.bot.relatedMessage(to,'幻想 0317 憨憨家',msg.id)
                if text == self.prefix.lower()+'憨憨定名':return self.bot.relatedMessage(to,'憨憨 0809 幻想家',msg.id)
                if text == self.prefix.lower()+'塔酥定名':return self.bot.relatedMessage(to,'塔酥 0922 彰化',msg.id)
                if text == self.prefix.lower()+'累計踢人':
                    txt='[ 累計踢人數 ]'
                    with open('txt/kc','r') as f:js=json.loads(f.read());f.close()
                    txt+=f'\n{js["mem"]}人'
                    txt+=f'\n尚可踢{"0" if js["mem"]>=150 else 150 - int(js["mem"])}人'
                    txt+=f'\n最後更改時間:{js["time"]}'
                    txt+=f'\n請注意用量 盡量在150人內'
                    self.bot.relatedMessage(to,txt,msg.id)
                if text.lower() == self.prefix.lower()+'ty':
                    if msg.toType == 0:
                        self.bot.sendMessage(to, text=u'@huan', contentMetadata={u'MENTION': json.dumps({'MENTIONEES':[{"S":"0","E":"5","M":to}]})}, contentType=0)
                if text.lower()==self.prefix.lower()+'retoken':
                    with open('txt/token','w') as f:f.write('None');f.close()
                    self.bot.relatedMessage(to,'重置完畢',msg.id)
                if text.lower()==self.prefix.lower()+'reun':
                    size=os.path.getsize('json/unsend.json')
                    if size >=1000:
                        mathsize=size/1000
                        kbmb='Kb'
                    elif size>= 1000000:
                        mathsize=size/1000000
                        kbmb='Gb'
                    else:
                        mathsize=size
                        kbmb='Mb'
                    self.un={"un":{}};json.dump(self.un,codecs.open('json/unsend.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False);self.bot.relatedMessage(to,f'重置完畢\n共{mathsize}{kbmb}',msg.id)
                if text == self.prefix.lower()+'重置':
                    with open('txt/kc','w') as f:f.write(str(json.dumps({"mem":0,"time":'無'})));f.close()
                    self.bot.relatedMessage(to,'重置成功',msg.id)
                if text.lower()=='mode':
                    txt='[ 設定 ]'
                    if to in self.joinkick:ifwar="開啟"
                    else:ifwar="關閉"
                    if to in self.settings['ProtectGroups']:ifpro="開啟"
                    else:ifpro="關閉"
                    txt+=f'\n自動更換個簽(半小時)\n|{"關閉" if self.settings["autochange"]==False else "開啟"}|\n'
                    with open('txt/text','r') as f:text=f.read();f.close()
                    txt+=f'\n自動更換個簽文字\n|{text}|\n'
                    txt+=f'\n線呈模式\n|{"加載線呈" if not self.settings["token"] else "預備線呈"}|\n'
                    txt+=f'\n預備線呈\n|{str(len(self.tokens))}|\n'
                    txt+=f'\n指令前墜(Prefix)\n|{"無" if self.prefix == "" else self.prefix}|\n'
                    txt+=f'\n自動加入網址\n|{"開啟" if self.settings["autojoin"] else "關閉"}|\n'
                    txt+=f'\n標註回覆\n|{"開啟" if self.settings["tagreply"] else "關閉"}|\n'
                    txt+=f'\n自動保護\n|{"開啟" if self.settings["protect"] else "關閉"}|\n'
                    txt+=f'\n貼圖轟炸\n|{"開啟" if self.settings["stickerkick"] else "關閉"}|\n'
                    txt+=f'\n入群踢\n|{ifwar}|\n'
                    txt+=f'\n群組保護\n|{ifpro}|'
                    txt+='\n[ 完 ]'
                    self.bot.relatedMessage(to,txt,msg.id)
                if "/r/ti/g/" in text.lower() and self.settings['autojoin']:
                    try:
                        link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                        links = link_re.findall(text)
                        n_links = []
                        for l in links:
                            if l not in n_links:n_links.append(l)
                        for ticket_id in n_links:
                            time.sleep(1)
                            try:
                                group = self.bot.findGroupByTicket(ticket_id)
                                self.bot.acceptGroupInvitationByTicket(group.id,ticket_id)
                                self.bot.relatedMessage(to,"加入成功\n群組名稱:{}\n人數:{}\n群組網址ID:\n{}\n群組ID:\n{}".format(str(group.name),str(len(group.members)),str(ticket_id),str(group.id)),op.message.id)
                            except Exception as e:self.bot.relatedMessage(to,str(e),msg.id)
                    except Exception as e:self.bot.relatedMessage(to,str(e),msg.id)
                elif 'ti/g/' in text and self.settings['autojoin']:
                    try:
                        link_re = re.compile('(?:line\:\/|line\.me)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                        links = link_re.findall(text)
                        n_links = []
                        for l in links:
                            if l not in n_links:n_links.append(l)
                        for ticket_id in n_links:
                            try:
                                time.sleep(1)
                                group = self.bot.findGroupByTicket(ticket_id)
                                self.bot.acceptGroupInvitationByTicket(group.id,ticket_id)
                                self.bot.relatedMessage(to,"加入成功\n群組名稱:{}\n人數:{}\n群組網址ID:\n{}\n群組ID:\n{}".format(str(group.name),str(len(group.members)),str(ticket_id),str(group.id)),op.message.id)
                            except Exception as e:self.bot.relatedMessage(to,str(e),msg.id)
                            time.sleep(1)
                    except Exception as e:self.bot.relatedMessage(to,str(e),msg.id)
                if text.lower().startswith(self.prefix.lower()+'un '):
                    try:
                        args = text.split(' ')
                        mes = 0
                        try:mes = int(args[1])
                        except:mes = 1
                        M = self.bot.getRecentMessagesV2(to, 1001)
                        MId = []
                        tmp=[]
                        task=[]
                        for ind,i in enumerate(M):
                            if ind == 0:pass
                            else:
                                if i._from == self.botmid:
                                    MId.append(i.id)
                                    if len(MId) == mes:break
                        if self.settings["token"] == True:
                            if len(self.tokens) < len(MId):
                                for x in range(len(MId)):
                                    self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                    tmp=self.tokens
                            else:tmp=self.tokens
                        else:
                            for x in range(len(MId)):tmp.append(LINE(self.bot.authToken,appName=self.device))
                        def unsMes(id,n):tmp[n].unsendMessage(id)
                        n=0
                        for i in MId:
                            t = threading.Thread(target=unsMes, args=(i,n))
                            n+=1
                            task.append(t)
                        for x in task:x.start()
                    except:pass
                if text.lower().startswith(self.prefix.lower()+'ri '):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:targets.append(x["M"])
                    for target in targets:
                        try:
                            self.bot.findAndAddContactsByMid(target)
                            self.bot.kickoutFromGroup(msg.to,[target])
                            self.bot.inviteIntoGroup(to,[target])
                        except:self.bot.relatedMessage(to,"戰神 你他媽腳斷了踹個洨???",op.message.id)
                if text.lower().startswith(self.prefix.lower()+'ti '):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:self.bot.findAndAddContactsByMid(target)
                        except:self.bot.relatedMessage(to,"你沒人緣 別了吧",op.message.id)
                    try:self.bot.inviteIntoGroup(to,targets)
                    except:self.bot.relatedMessage(to,"你手斷了你要拉鬼魂???",op.message.id)
                if text.lower().startswith("rex"):
                    txt = msg.text.split(" ")
                    if "Rex" in txt:text = msg.text.replace("Rex "+txt[1]+" ","")
                    elif "rex" in txt:text = msg.text.replace("rex "+txt[1]+" ","")
                    if text != "":
                        task=[]
                        num = int(txt[1])
                        n=0
                        tmp=[]
                        if self.settings["token"] == True:
                            if len(self.tokens) < num:
                                for x in range(num):
                                    self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                    tmp=self.tokens
                            else:tmp=self.tokens
                        else:
                            for x in range(num):tmp.append(LINE(self.bot.authToken,appName=self.device))
                        for x in range(num):
                            if "MENTION" in msg.contentMetadata.keys()!= None:
                                datalist = eval(msg.contentMetadata["MENTION"])["MENTIONEES"]
                                taglist = []
                                for data in datalist:
                                    tags = int(data["S"]) - 5 - len(txt[1])
                                    tage = int(data["E"]) - 5 - len(txt[1])
                                    tagm = data["M"]
                                    taglist.append({"S":str(tags), "E" :str(tage), "M":tagm})
                                contentMetadata={u"MENTION": json.dumps({"MENTIONEES":taglist})}
                                t=threading.Thread(target=tmp[n].relatedMessage,args=(msg.to, text,msg.id, contentMetadata))
                                task.append(t)
                                n+=1
                            else:
                                t=threading.Thread(target=tmp[n].relatedMessage,args=(msg.to, text,msg.id))
                                task.append(t)
                                n+=1
                        for x in task:x.start()
                if text.lower()==self.prefix.lower()+'gid':self.bot.sendMessage(to,to)
                if text == self.prefix.lower()+'地區':self.bot.relatedMessage(to,f"➲機器帳號語言: {self.bot.getSettings().preferenceLocale}\n➲帳號地區: {self.bot.getProfile().regionCode}",msg.id)
                if text.lower().startswith(self.prefix.lower()+'call '):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    list_ = msg.text.split(" ")
                    number = list_[1]
                    x=1
                    if msg.toType == 2:
                        group = self.bot.getGroup(to)
                        num = int(number)
                        self.bot.relatedMessage(to, "開始邀請...",msg.id)
                        start = time.time()
                        print('開始邀請...')
                        for x in tqdm(range(num)):
                            self.bot.inviteIntoGroupCall(to,[inkey],1)
                            time.sleep(0.06)
                            x+=1
                        elapsed_time = time.time() - start
                        print('邀請完畢!')
                        self.bot.sendMessage(to, "邀請完畢 共邀請了{}次\n若無請確保有人通話中\n邀請時間:{}秒".format(number,str(elapsed_time)))
                    if msg.toType == 1:
                        room = self.bot.getRoom(to)
                        num = int(number)
                        self.bot.relatedMessage(to, "開始邀請...",msg.id)
                        start = time.time()
                        print('開始邀請...')
                        for x in tqdm(range(num)):
                            self.bot.inviteIntoGroupCall(to,[inkey],1)
                            time.sleep(0.06)
                            x+=1
                        elapsed_time = time.time() - start
                        print('邀請完畢!')
                        self.bot.sendMessage(to, "邀請完畢 共邀請了{}次\n若無請確保有人通話中\n邀請時間:{}秒".format(number,str(elapsed_time)))
                if text.lower().startswith(self.prefix.lower()+"vk "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:targets.append(x["M"])
                    for x in targets:
                        try:self.bot.findAndAddContactsByMid(x)
                        except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    for x in targets:
                        try:self.bot.kickoutFromGroup(msg.to,[x])
                        except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    try:self.bot.inviteIntoGroup(to,targets)
                    except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    for x in targets:
                        try:self.bot.cancelGroupInvitation(to,[x])
                        except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    tz = pytz.timezone("Asia/Taipei")				
                    timeNow = datetime.datetime.now(tz=tz)
                    with open('txt/kc','r') as f:
                        js=json.loads(f.read())
                        f.close()
                    with open('txt/kc','w') as f:
                        js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                        js["mem"]+=len(targets)
                        f.write(str(json.dumps(js)))
                        f.close()
                if text.lower().startswith(self.prefix.lower()+"vki "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for x in targets:
                        try:self.bot.findAndAddContactsByMid(x)
                        except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    for x in targets:
                        try:self.bot.kickoutFromGroup(msg.to,[x])
                        except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    try:self.bot.inviteIntoGroup(to,targets)
                    except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    for x in targets:
                        try:self.bot.cancelGroupInvitation(to,[x])
                        except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    try:self.bot.inviteIntoGroup(to,targets)
                    except:self.bot.relatedMessage(to,"目前處於 帳號規制狀態中",op.message.id)
                    tz = pytz.timezone("Asia/Taipei")				
                    timeNow = datetime.datetime.now(tz=tz)
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    with open('txt/kc','r') as f:
                        js=json.loads(f.read())
                        f.close()
                    with open('txt/kc','w') as f:
                        js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                        js["mem"]+=len(targets)
                        f.write(str(json.dumps(js)))
                        f.close()
                if text.lower().startswith(self.prefix.lower()+'call:'):
                    number = msg.text.replace("call:","")
                    x=1
                    try:
                        group = self.bot.getGroup(to)
                        gMembMids = [contact.mid for contact in group.members]
                        num = int(number)
                        start = time.time()
                        print('開始邀請...')
                        for x in tqdm(range(num)):
                            self.bot.inviteIntoGroupCall(to,gMembMids,1)
                            time.sleep(0.06)
                            x+=1
                        elapsed_time = time.time() - start
                        print('邀請完畢!')
                        self.bot.sendMessage(to, "邀請完畢 共邀請了{}次\n若無請確保有人通話中\n邀請時間:{}秒".format(number,str(elapsed_time)))
                    except:
                        room = self.bot.getRoom(to)
                        rMembMids = [contact.mid for contact in room.contacts]
                        num = int(number)
                        print('開始邀請...')
                        start = time.time()
                        for x in tqdm(range(num)):
                            self.bot.inviteIntoGroupCall(to,gMembMids,1)
                            time.sleep(0.06)
                            x+=1
                        elapsed_time = time.time() - start
                        print('邀請完畢!')
                        self.bot.sendMessage(to, "邀請完畢 共邀請了{}次\n若無請確保有人通話中\n邀請時間:{}秒".format(number,str(elapsed_time)))
                if text.lower().startswith(self.prefix.lower()+'sj:'):
                    try:num=int(text[(len(self.prefix)+3):])
                    except:return self.bot.sendMessage(to,'無效的數字')
                    for x in range(num):self.bot.acceptGroupInvitation(to);time.sleep(0.5)
                    self.bot.sendMessage(to,'完成動作')
                if text.lower().startswith(self.prefix.lower()+'ak:'):
                    nam=text[(len(self.prefix)+3):]
                    mem = [x for x in self.bot.getGroup(to).members]
                    n=0
                    for x in mem:
                        if x not in self.kl['kick']:
                            if nam in x.displayName:self.kl['kick'].append(x.mid);n+=1
                    self.bot.sendMessage(to,f'完成動作\n{n}人')
                if text.lower().startswith(self.prefix.lower()+'ak '):
                    nam=text[(len(self.prefix)+3):]
                    n=0
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:targets.append(x["M"])
                    n=0
                    for x in targets:
                        if x not in self.kl['kick']:self.kl['kick'].append(x);n+=1
                    self.bot.sendMessage(to,f'完成動作\n{n}人')
                if text.lower().startswith(self.prefix.lower()+'ac:'):
                    nam=text[(len(self.prefix)+3):]
                    if self.bot.getGroup(to).invitee == None:return self.bot.sendMessage(to,'無法加入')
                    mem = [x for x in self.bot.getGroup(to).invitee]
                    n=0
                    for x in mem:
                        if x not in self.kl['cancel']:
                            if nam in x.displayName:self.kl['cancel'].append(x.mid);n+=1
                    self.bot.sendMessage(to,f'完成動作\n{n}人')
                if text.lower() == self.prefix.lower()+'clear':
                    self.kl={'kick':[],'cancel':[]}
                    self.bot.sendMessage(to,'完成動作')
                if text.lower() == self.prefix.lower()+'list':
                    txt='[ kick ]'
                    n=1
                    if self.kl['kick'] != []:
                        for x in self.kl['kick']:txt+=f"\n{n}. {self.bot.getContact(x).displayName}";n+=1
                    else:txt+='\n空'
                    n=0
                    txt+='\n[ cancel ]'
                    if self.kl['cancel'] != []:
                        for x in self.kl['cancel']:txt+=f"\n{n}. {self.bot.getContact(x).displayName}";n+=1
                    else:txt+='\n空'
                    self.bot.sendMessage(to,txt)
                if text.lower() == self.prefix.lower()+'go':
                    task=[]
                    tmp=[]
                    if msg.toType != 2:return
                    try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    except Exception as e:
                        if e.reason == "request blocked":return self.bot.relatedMessage(to,'你他媽腳斷了踹個洨???',msg.id)
                    if self.settings["token"] == True:
                        if len(self.tokens) < len(self.kl['kick'])+len(self.kl['cancel']):
                            for x in range(len(self.kl['kick'])+len(self.kl['cancel'])):
                                self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                tmp=self.tokens
                        else:tmp=self.tokens
                    else:
                        for x in range(len(self.kl['kick'])+len(self.kl['cancel'])):tmp.append(LINE(self.bot.authToken,appName=self.device))
                    g=self.bot.getGroupWithoutMembers(to)
                    g.preventedJoinByTicket =True
                    n=0
                    self.kl['kick']=random.shuffle(self.kl['kick'])
                    for x in self.kl['kick']:
                        t=threading.Thread(target=tmp[n].kickoutFromGroup,args=(to,[x]))
                        tz = pytz.timezone("Asia/Taipei")				
                        timeNow = datetime.datetime.now(tz=tz)
                        with open('txt/kc','r') as f:
                            js=json.loads(f.read())
                            f.close()
                        with open('txt/kc','w') as f:
                            js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                            js["mem"]+=1
                            f.write(str(json.dumps(js)))
                            f.close()
                        n+=1
                        task.append(t)
                    self.kl['cancel']=random.shuffle(self.kl['cancel'])
                    for x in self.kl['cancel']:
                        t=threading.Thread(target=tmp[n].cancelGroupInvitation,args=(to,[x]))
                        n+=1
                        task.append(t)
                    self.joinkick[to] = True
                    self.bot.sendMessage(to,'拆你全家')
                    for x in task:x.start()
                    threading.Thread(target=self.bot.updateGroup,args=(g,)).start()
                if text.lower().startswith(self.prefix.lower()+'k ') or text.lower().startswith(self.prefix.lower()+'kick ') or text.startswith(self.prefix.lower()+'踹 '):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    task=[]
                    if msg.toType != 2:return
                    try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    except Exception as e:
                        if e.reason == "request blocked":return self.bot.relatedMessage(to,'你他媽腳斷了踹個洨???',msg.id)
                    for x in key["MENTIONEES"]:targets.append(x["M"])
                    if self.settings["token"] == True:
                        if len(self.tokens) < len(targets):
                            for x in range(len(targets)):
                                self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                tmp=self.tokens
                        else:tmp=self.tokens
                    else:
                        for x in range(len(targets)):tmp.append(LINE(self.bot.authToken,appName=self.device))
                    n=0
                    for x in targets:
                        if x not in self.botmid:
                            t=threading.Thread(target=tmp[int(n)].kickoutFromGroup,args=(to,[x]))
                            n+=1
                            task.append(t)
                            tz = pytz.timezone("Asia/Taipei")
                            timeNow = datetime.datetime.now(tz=tz)
                            with open('txt/kc','r') as f:
                                js=json.loads(f.read())
                                f.close()
                            with open('txt/kc','w') as f:
                                js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                                js["mem"]+=1
                                f.write(str(json.dumps(js)))
                                f.close()
                    for x in task:x.start()
                if text.lower().startswith(self.prefix.lower()+"nk:"):
                    _name = text[(len(self.prefix)+3):]
                    gs = self.bot.getGroup(op.message.to)
                    targets = []
                    task=[]
                    try:self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    except Exception as e:
                        if e.reason == "request blocked":return self.bot.relatedMessage(to,'你已經失去了所有 還想幹嘛',msg.id)
                    with open('txt/kc','r') as f:
                        num=json.loads(f.read())['mem']
                        if len(gs.members) >=(150-int(num)):return self.bot.relatedMessage(to,'你腳已經快骨折了 你不用休息嗎???',msg.id)
                    for g in gs.members:
                        if _name in g.displayName:targets.append(g.mid)
                    if targets == []:pass
                    else:
                        if self.settings["token"] == True:
                            if len(self.tokens) < len(targets):
                                for x in range(len(targets)):
                                    self.tokens.append(LINE(self.bot.authToken,appName=self.device))
                                    tmp=self.tokens
                            else:tmp=self.tokens
                        else:
                            for x in range(len(targets)):tmp.append(LINE(self.bot.authToken,appName=self.device))
                        n=0
                        
                        for x in targets:
                            if x not in self.botmid:
                                t=threading.Thread(target=tmp[int(n)].kickoutFromGroup,args=(to,[x]))
                                n+=1
                                task.append(t)
                                tz = pytz.timezone("Asia/Taipei")				
                                timeNow = datetime.datetime.now(tz=tz)
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                with open('txt/kc','r') as f:
                                    js=json.loads(f.read())
                                    f.close()
                                with open('txt/kc','w') as f:
                                    js["time"]=timeNow.strftime('%Y/%m/%d:%H:%M:%S')
                                    js["mem"]+=1
                                    f.write(str(json.dumps(js)))
                                    f.close()
                        for x in task:x.start()
                if text.lower()==self.prefix.lower()+'link':
                    self.bot.sendMessage(to,str(self.bot.reissueGroupTicket(to)))
                if text.lower().startswith(self.prefix.lower()+'link:'):
                    cos=text[(len(self.prefix)+5):]
                    g=self.bot.getGroupWithoutMembers(to)
                    if cos == 'on':
                        g.preventedJoinByTicket = False
                        self.bot.updateGroup(g)
                    if cos == 'off':
                        g.preventedJoinByTicket = True
                        self.bot.updateGroup(g)
                    if cos == 'status':self.bot.sendMessage(to,str(g.preventedJoinByTicket))
                if text.lower().startswith(self.prefix.lower()+'sys:'):
                    try:exec(str(text[(len(self.prefix)+4):]))
                    except Exception as e:self.bot.relatedMessage(to,str(e),msg.id)
                if text.lower() == self.prefix.lower()+'rebot':
                    self.bot.relatedMessage(to,'重開中...',msg.id)
                    f=open('txt/reb','w')
                    js={"to":to,"id":msg.id}
                    f.write(str(json.dumps(js)))
                    f.close()
                    python = sys.executable
                    os.execl(python, python, *sys.argv)
                if text.lower() == self.prefix.lower()+'llag':
                    with open('txt/lag','r') as f:
                        self.bot.sendMessage(to,f.read())
                        f.close()
                if text.lower() == self.prefix.lower()+'llag2':
                    with open('txt/lag2','r') as f:
                        self.bot.sendMessage(to,f.read())
                        f.close()
                if text.lower() == self.prefix.lower()+'llag3':
                    with open('txt/lag3','r') as f:
                        self.bot.sendMessage(to,f.read())
                        f.close()
                if text.lower() == self.prefix.lower()+'llag4':
                    self.bot.sendAudio(to,'data/lag.mp3')
                if text.lower() == self.prefix.lower()+'ac':
                    if to not in self.test:
                        self.test[to]=True
                        self.bot.relatedMessage(to,'已開啟',msg.id)
                    else:
                        del self.test[to]
                        self.bot.relatedMessage(to,'已關閉',msg.id)
                if text.lower() == self.prefix.lower()+'mine':
                    try:
                        self.bot.kickoutFromGroup(msg.to, ["fuck you"])
                    except Exception as e:
                        if e.reason == "request blocked":aa ="🔴"
                        else:aa ="🟢"
                        if msg.toType == 2:
                            try:
                                self.bot.inviteIntoGroup(msg.to, ["fuck you"])
                                bb ="🟢"
                            except:bb="🔴"
                        if msg.toType in [0,1]:bb='⚪'
                        try:
                            self.bot.findContactsByUserid("huanxiang")
                            cc ="🟢"
                        except:cc ="🔴"
                        try:
                            if msg.toType in [0,1]:dd='⚪'
                            else:
                                url=self.bot.reissueGroupTicket(to)
                                self.bot.findGroupByTicket(url)
                                dd='🟢'
                        except:dd='🔴'
                    self.bot.relatedMessage(to,"ΞΞΞΞΞ〘機器狀態查詢〙ΞΞΞΞΞ\n※踢人狀態:" + str(aa) + "\n※邀請狀態:" + str(bb) + "\n※取消狀態:🟢\n※加友狀態:" + str(cc) +"\n※網址加入狀態:" + str(dd) +"\n※版本資訊: SelfBot\nΞΞΞΞΞ〘Hx ßôt〙ΞΞΞΞΞ",op.message.id)
            if op.type == 65:
                msg_id = op.param2
                msg_dict=self.un
                if msg_id in msg_dict["un"]:
                    rereadtime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(int(round(msg_dict["un"][msg_id]["createdTime"]/1000))))
                    newtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    if 'text' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回訊息]\n%s\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]\n%s\n[訊息位置]\n%s\n(%s)'%(msg_dict["un"][msg_id]["text"],rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_ , contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                        del msg_dict["un"][msg_id]
                    elif 'id' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回了一張貼圖]\n在下面\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]\n%s\n[訊息位置]\n%s\n(%s)'%(rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                        yesno = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/' + msg_dict["un"][msg_id]["id"] + '/IOS/sticker_animation.png'
                        ok = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/' + msg_dict["un"][msg_id]["id"] + '/ANDROID/sticker.png'
                        while 1:
                            try:
                                self.bot.sendImageWithURL('c2d5bef799adbcec049ec02562066fb2c', ok)
                                break
                            except:continue
                        del msg_dict["un"][msg_id]
                    elif 'mid' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回了一個友資]\n在下面\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]\n%s\n[訊息位置]\n%s\n(%s)'%(rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                        self.bot.sendContact('c2d5bef799adbcec049ec02562066fb2c',msg_dict["un"][msg_id]["mid"])
                        del msg_dict["un"][msg_id]
                    elif 'sound' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回了一個錄音檔]\n在下面\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]\n%s\n[訊息位置]\n%s\n(%s)'%(rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                        while 1:
                            try:
                                self.bot.sendAudio('c2d5bef799adbcec049ec02562066fb2c', msg_dict["un"][msg_id]["sound"])
                                break
                            except:continue
                        del msg_dict["un"][msg_id]
                    elif 'file' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回了一個檔案]\n在下面\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]\n%s\n[訊息位置]\n%s\n(%s)'%(rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                        while 1:
                            try:
                                self.bot.sendFile('c2d5bef799adbcec049ec02562066fb2c', msg_dict["un"][msg_id]["file"])
                                break
                            except:continue
                        del msg_dict["un"][msg_id]
                    elif 'image' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回了一張圖片]\n在下面\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]\n%s\n[訊息位置]\n%s\n(%s)'%(rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                        while 1:
                            try:
                                self.bot.sendImage('c2d5bef799adbcec049ec02562066fb2c', msg_dict["un"][msg_id]["image"])
                                break
                            except:continue
                        del msg_dict["un"][msg_id]
                    elif 'Video' in msg_dict["un"][msg_id]:
                        aa = '{"S":"0","E":"10","M":'+json.dumps(msg_dict["un"][msg_id]["from"])+'}'
                        c="私聊" if op.param1[0:1] == 'u' else "副本" if op.param1[0:1] == 'r' else self.bot.getGroup(op.param1).name
                        txr = '[收回了一部影片]\n在下面\n[發送時間]\n%s\n[收回時間]\n%s\n[收回的人]%s\n[訊息位置]\n%s\n(%s)'%(rereadtime,newtime,msg_dict["un"][msg_id]["from"],op.param1,c)
                        pesan = '@huanxiang \n'
                        text_ =  pesan + txr
                        while 1:
                            try:
                                self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c', text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
                                break
                            except:continue
                        self.bot.sendVideo('c2d5bef799adbcec049ec02562066fb2c', msg_dict["un"][msg_id]["Video"])
                        del msg_dict["un"][msg_id]
                    else:pass
                    json.dump(self.un,codecs.open('json/unsend.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        except AssertionError as e:print(str(e))
        except Exception as e:self.bot.sendMessage('c2d5bef799adbcec049ec02562066fb2c','錯誤:\n'+str(e))
        finally:return
#======================================================================#
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#                  Copyright © 2018-2021 幻想 版權所有                  #
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#======================================================================#