from linepy import*
import os
def gettoken:
    k1 = LINE()
    return k1.authToken
    k1.logout()
    sys.exit()