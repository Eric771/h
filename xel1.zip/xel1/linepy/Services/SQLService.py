import pymysql
class SQLService:
    def __init__(self):
        self.SQL_Account={
            'host':'bao.baoserver.com',
            'user':'computer',
            'passwd':'qwer8520',
            'charset':'utf8mb4',
            'db':'computer_line_bot'
        }
    def add_value(self,gid,amount):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
        to =""
        mon = 0
        for mode in cursor.fetchall():
            to = mode[0]
            mon = mode[1]
        if gid in to :
            cursor.execute("UPDATE math SET Amount = Amount+{} WHERE Gid = '{}'".format(amount,str(gid)))
            cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
            for mode in cursor.fetchall():
                Num_my = mode[1]
                Type_my = mode[2]
            num_= Num_my
            type_= Type_my
        else:
            cursor.execute("""INSERT INTO math(Gid,Amount,Type)VALUES('{}',{},'{}');""".format(str(gid),str(amount),'t'))
            num_ = amount
            type_= type
        cursor = conn.cursor()
        conn.commit();conn.close();cursor.close()
        if 0>num_:
            txt=f'目前欠:{str(num_)[1:]}{"Rmb" if type_ == "r" else "Twd"}'
            Text_type = "目前欠:"
            text_money = f'{str(num_)[1:]}{"Rmb" if type_ == "r" else "Twd"}'
        else:
            txt=f'目前總計:{str(num_)}{"Rmb" if type_ == "r" else "Twd"}'
            Text_type = "目前總計:"
            text_money = f'{str(num_)}{"Rmb" if type_ == "r" else "Twd"}'
        txt+=f'\n金額:{mon}>{text_money}'
        return txt
    def del_value(self,gid,amount):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
        to =""
        mon = 0
        for mode in cursor.fetchall():
            to = mode[0]
            mon = mode[1]
        if gid in to:
            cursor.execute("UPDATE math SET Amount = Amount-{} WHERE Gid = '{}'".format(amount,str(gid)))
            cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
            for mode in cursor.fetchall():
                Num_my = mode[1]
                Type_my = mode[2]
            num_= Num_my
            type_= Type_my
        else:
            cursor.execute("""INSERT INTO math(Gid,Amount,Type)VALUES('{}',{},'{}');""".format(str(gid),str(amount),'t'))
            num_ = amount
            type_= type
        cursor = conn.cursor()
        conn.commit();conn.close();cursor.close()
        if 0>num_:
            txt=f'目前欠:{str(num_)[1:]}{"Rmb" if type_ == "r" else "Twd"}'
            Text_type = "目前欠:"
            text_money = f'-{str(num_)[1:]}{"Rmb" if type_ == "r" else "Twd"}'
        else:
            txt=f'目前總計:{str(num_)}{"Rmb" if type_ == "r" else "Twd"}'
            Text_type = "目前總計:"
            text_money = f'{str(num_)}{"Rmb" if type_ == "r" else "Twd"}'
        txt+=f'\n金額:{mon}>{text_money}'
        return txt
    def clear_value(self,gid):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
        to =""
        for mode in cursor.fetchall():to = mode[0]
        if gid in to :
            # DELETE 
            #  DELETE FROM tutorials_tbl WHERE tutorial_id=3;
            cursor.execute("""DELETE FROM math WHERE Gid='{}'""".format(str(gid)))
            cursor = conn.cursor()
            conn.commit();conn.close();cursor.close()
            return "清除成功"
        else:
            return '目前無紀錄'
    def check_value(self,gid):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
        to ="";Num_my= 0; Type_my = 't'
        for mode in cursor.fetchall():
            to = mode[0]
            Num_my = mode[1]
            Type_my = mode[2]
        if gid in to :
            # return f'[目前總帳]\n價位:\n  {Num_my}{"台幣" if Type_my == "t" else "人民幣"}'
            text =  "目前總帳"
            text += f'\n{Num_my}{"台幣" if Type_my == "t" else "人民幣"}'
        else:
            # return "目前無紀錄"
            text =  "目前總帳"
            text += "\n目前無紀錄"
        return text
    def change_type(self,gid):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        cursor.execute("""SELECT  *  FROM `math` WHERE  `Gid` = '{}' ;	""".format(str(gid)))
        to ="";text = "[更換]";type_x= "t"
        for mode in cursor.fetchall():
            to = mode[0]
            type_x = mode[2]
        if gid in to :
            if "t" in type_x:
                cursor.execute("UPDATE math SET Type = 'r' WHERE Gid = '{}'".format(str(gid)))
                text += "\nTWD => RMB"
                text += "\n成功更換成RMB"
            elif "r" in type_x:
                cursor.execute("UPDATE math SET Type = 't' WHERE Gid = '{}'".format(str(gid)))
                text += "\nRMB => TWD"
                text += "\n成功更換成TWD"
        cursor = conn.cursor()
        conn.commit();conn.close();cursor.close()
        return text
    def add_admin(self,users=[]):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        a = 0
        ans=[]
        for x in users:
            midX= ""
            cursor.execute("""SELECT  *  FROM `admin` WHERE  `sender` = '{}' ;	""".format(str(x)))
            for mode in cursor.fetchall():midX = mode[0]
            if x not in midX:
                cursor.execute("""INSERT INTO admin(sender)VALUES('{}');""".format(str(x)))
                a+=1
                ans.append({'mid':x,'success':True})
            else:
                ans.append({'mid':x,'success':False})
                a+=1
        conn.commit();conn.close();cursor.close()
        return ans
    def del_admin(self,users=[]):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        a = 0
        ans=[]
        for x in users:
            midX= ""
            cursor.execute("""SELECT  *  FROM `admin` WHERE  `sender` = '{}' ;	""".format(str(x)))
            for mode in cursor.fetchall():midX = mode[0]
            if x in midX:
                cursor.execute("""DELETE FROM admin WHERE sender='{}'""".format(str(x)))
                a+=1
                ans.append({'mid':x,'success':True})
            else:
                ans.append({'mid':x,'success':False})
                a+=1
        conn.commit();conn.close();cursor.close()
        return ans
    def isAdmin(self,mid):
        conn = pymysql.connect(
            host=self.SQL_Account['host'],
            user=self.SQL_Account['user'],
            passwd=self.SQL_Account['passwd'],
            charset=self.SQL_Account['charset'],
            db = self.SQL_Account['db']
        )
        cursor = conn.cursor()
        cursor.execute(f"""SELECT  *  FROM `admin` WHERE `sender` = '{mid}';	""")
        mids=[x[0] for x in cursor.fetchall()]
        isadmin=False
        if mid in mids:isadmin=True
        conn.commit();conn.close();cursor.close()
        return isadmin