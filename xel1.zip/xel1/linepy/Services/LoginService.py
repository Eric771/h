from .IniService import IniService
from .. import LINE
from .DiscordService import DiscordService
class LoginService:
    def __init__(self):pass
    def __login__(self,Mail,Password):
        if IniService().getToken()!='None':
            try:
                return '0',LINE(IniService().getToken())
            except:
                IniService().writeToken('None')
        try:return '0',LINE(Mail,Password)
        except Exception as Except:
            try:
                print(str(Except))
                IniService().Stop_Bot()
                DiscordService().power_off()
                Reason=Except.reason
                ErrorList=['blocked user','']
                if Reason not in ErrorList:
                    return '1',str(Except)
                if Reason == '':
                    return '1','Account Freeze'
                if Reason == 'blocked user':
                    return '1','Account Blocked'
            except:return '1','Unkown'
        except:return '1','Unkown'