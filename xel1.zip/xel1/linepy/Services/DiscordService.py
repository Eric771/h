from discord_webhook import DiscordWebhook, DiscordEmbed
class DiscordService:
    def __init__(self):
        self.url=['https://discord.com/api/webhooks/930450322160242708/pJRu9J_xzYaSNrdBRXGEhE7QhtC8qGiS5FXpF39t7jevrzTtlb0mx426R-CtD28HCRPf','https://discordapp.com/api/webhooks/931939362919309334/YtWfEG2mJ8j-eMK1m9y8GbIdsALeERakpQINFGaNIi4bI0RF8QPTjVJ6CB1KV2mctW5l']
        self.webhook1 = DiscordWebhook(
            url = self.url[0],
            username = "Server"
        )
        self.webhook2 = DiscordWebhook(
            url = self.url[1],
            username = "Server(備用)"
        )
    def start(self):
        embed = DiscordEmbed(
            color=0x00ff00,
            title ="[+]機器開機成功"
            )
        embed.set_footer(text="幻想bot.")
        embed.set_timestamp()
        self.webhook1.add_embed(embed)
        if self.webhook1.execute().status_code != 200:
            self.webhook2.add_embed(embed)
            self.webhook2.execute()
    def starting(self):
        embed = DiscordEmbed(
            color=0x0000ff,
            title ="[+]機器開機中"
            )
        embed.set_footer(text="幻想bot.")
        embed.set_timestamp()
        self.webhook1.add_embed(embed)
        if self.webhook1.execute().status_code != 200:
            self.webhook2.add_embed(embed)
            self.webhook2.execute()
    def power_off(self):
        embed = DiscordEmbed(
            color=0xff0000,
            title ="[-]機器已關機"
            )
        embed.set_footer(text="幻想bot.")
        embed.set_timestamp()
        self.webhook1.add_embed(embed)
        if self.webhook1.execute().status_code != 200:
            self.webhook2.add_embed(embed)
            self.webhook2.execute()
    def post(self,message):
        embed = DiscordEmbed(
            color=0x007ef5,
            description =str(message),
            title='[+]新訊息'
        )
        embed.set_footer(text="幻想bot.")
        embed.set_timestamp()
        self.webhook1.add_embed(embed)
        if self.webhook1.execute().status_code != 200:
            self.webhook2.add_embed(embed)
            self.webhook2.execute()
