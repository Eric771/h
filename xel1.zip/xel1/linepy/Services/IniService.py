import configparser
class IniService:
    def __init__(self):
        self.config=configparser.ConfigParser()
        self.config.read('/root/math/config.ini',encoding='utf-8')
    def StartUp(self):
        self.config.set('Bot','isRunning','True')
        with open('/root/math/config.ini', 'w') as configfile:
            self.config.write(configfile)
    def Stop_Bot(self):
        self.config.set('Bot','isRunning','False')
        with open('/root/math/config.ini', 'w') as configfile:
            self.config.write(configfile)
    def getToken(self):
        return self.config.get('Account','token')
    def writeToken(self,value):
        self.config.set('Account','Token',value)
        with open('/root/math/config.ini', 'w') as configfile:
            self.config.write(configfile)