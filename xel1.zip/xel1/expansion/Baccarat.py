import json,time,random,codecs
class Baccarat:
    def __init__(self,client):
        #載入資料庫
        self.data=json.load(codecs.open('expansion/data/hand_group.json','r'))
        self.userdata=json.load(codecs.open('expansion/data/userdata.json','r'))
        self.client=client
        print(f'Client連接成功\n名稱:{self.client.profile.displayName}')
        self.Control = {
            "A":1,
            "2":2,
            "3":3,
            "4":4,
            "5":5,
            "6":6,
            "7":7,
            "8":8,
            "9":9,
            "10":0,
            "J":0,
            "Q":0,
            "K":0
        }
    def start_game(self,GroupId):
        #開始遊戲
        if GroupId not in self.data['running']:
            self.data['running'][GroupId]={"players":{},"bet_time":None}
            return self.wait_for_bet(GroupId)
    def Choose_playing_cards(self):
        try:
            number=["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
            Color = ["♣","♠","♥","♦"]
            resultnumber = random.choice(number)
            resultColor = random.choice(Color)
            return resultColor , resultnumber
        except Exception as e:print(f'[-]{e}')
    def calculate_game(self,GroupId):
        if self.data['running'][GroupId]['players']:
            #處理賭博結果
            ##
            self.data["Baccarat"][GroupId]["Game_stage"]="Waiting to start"
        self.data["Baccarat"][GroupId]["send"]=[]
        self.data["Baccarat"][GroupId]["village"]={}
        self.data["Baccarat"][GroupId]["idle"]={}
        self.data["Board"]+=1
        self.save_data()
        time.sleep(0.1)
        Initial_state = "？？"
        Initial_num = 0
        loc=self.data["Baccarat"][GroupId]
        self.data["Baccarat"][GroupId]["send"].append(f"\n莊|({Initial_state})({Initial_state})「{Initial_num}」\n閒|({Initial_state})({Initial_state})「{Initial_num}」")
        Color , number = self.Choose_playing_cards()
        playing_cards=str(Color)+str(number)
        print(playing_cards)
        playing_cards_num = int(str(self.Control[number]))
        self.data["Baccarat"][GroupId]["idle"]["Handone"]={}
        self.data["Baccarat"][GroupId]["idle"]["Handone"]["Card"]=playing_cards
        self.data["Baccarat"][GroupId]["idle"]["Handone"]["num"]=number
        self.data["Baccarat"][GroupId]["idle"]["Handone"]["value"]=playing_cards_num
        loc=self.data["Baccarat"][GroupId]
        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({Initial_state})({Initial_state})「{Initial_num}」\n閒|({loc["idle"]["Handone"]["Card"]})({Initial_state})「{loc["idle"]["Handone"]["value"]}」')
        Color , number = self.Choose_playing_cards()
        playing_cards=str(Color)+str(number)
        print(playing_cards)
        playing_cards_num = int(str(self.Control[number]))
        self.data["Baccarat"][GroupId]["village"]["Handone"]={}
        self.data["Baccarat"][GroupId]["village"]["Handone"]["Card"]=playing_cards
        self.data["Baccarat"][GroupId]["village"]["Handone"]["num"]=number
        self.data["Baccarat"][GroupId]["village"]["Handone"]["value"]=playing_cards_num
        loc=self.data["Baccarat"][GroupId]
        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({Initial_state})「{loc["village"]["Handone"]["value"]}」\n閒|({loc["idle"]["Handone"]["Card"]})({Initial_state})「{loc["idle"]["Handone"]["value"]}」')
        Color , number = self.Choose_playing_cards()
        playing_cards=str(Color)+str(number)
        print(playing_cards)
        playing_cards_num = int(str(self.Control[number]))
        self.data["Baccarat"][GroupId]["idle"]["Handtwo"]={}
        self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["Card"]=playing_cards
        self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["num"]=number
        self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["value"]=playing_cards_num
        Final_value_idle=int(self.data["Baccarat"][GroupId]["idle"]["Handone"]["value"])+int(self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["value"])
        if Final_value_idle >= 10:Final_value_idle-=10
        self.data["Baccarat"][GroupId]["Win_or_lose"]={}
        self.data["Baccarat"][GroupId]["Win_or_lose"]["idle"]=Final_value_idle
        loc=self.data["Baccarat"][GroupId]
        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({Initial_state})「{loc["village"]["Handone"]["value"]}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})「{Final_value_idle}」')
        Color , number = self.Choose_playing_cards()
        playing_cards=str(Color)+str(number)
        print(playing_cards)
        playing_cards_num = int(str(self.Control[number]))
        self.data["Baccarat"][GroupId]["village"]["Handtwo"]={}
        self.data["Baccarat"][GroupId]["village"]["Handtwo"]["Card"]=playing_cards
        self.data["Baccarat"][GroupId]["village"]["Handtwo"]["num"]=number
        self.data["Baccarat"][GroupId]["village"]["Handtwo"]["value"]=playing_cards_num
        Final_value_village=int(self.data["Baccarat"][GroupId]["village"]["Handone"]["value"])+int(self.data["Baccarat"][GroupId]["village"]["Handtwo"]["value"])
        if Final_value_village >= 10:Final_value_village-=10
        self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]=Final_value_village
        loc=self.data["Baccarat"][GroupId]
        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})「{Final_value_idle}」')
        time.sleep(0.1)
        if self.data["Baccarat"][GroupId]["Win_or_lose"]["village"] == self.data["Baccarat"][GroupId]["Win_or_lose"]["idle"]:pass
        else:
            idleOutsourcing=False
            if str(Final_value_idle) in ["012345"] and str(Final_value_village) in ["0123456","7"]:
                print("閒家補牌")
                idleOutsourcing=True
                Color , number = self.Choose_playing_cards()
                playing_cards=str(Color)+str(number)
                playing_cards_num = int(str(self.Control[number]))
                print(playing_cards)
                self.data["Baccarat"][GroupId]["idle"]["Handthree"]={}
                self.data["Baccarat"][GroupId]["idle"]["Handthree"]["Card"]=playing_cards
                self.data["Baccarat"][GroupId]["idle"]["Handthree"]["num"]=number
                self.data["Baccarat"][GroupId]["idle"]["Handthree"]["value"]=playing_cards_num
                Final_value_idle+=self.data["Baccarat"][GroupId]["idle"]["Handthree"]["value"]
                if Final_value_idle >= 10:Final_value_idle-=10
                self.data["Baccarat"][GroupId]["Win_or_lose"]["idle"]=Final_value_idle
                loc=self.data["Baccarat"][GroupId]
                self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})({loc["idle"]["Handthree"]["Card"]})「{Final_value_idle}」')
            else:
                self.data["Baccarat"][GroupId]["idle"]["Handthree"]={}
                self.data["Baccarat"][GroupId]["idle"]["Handthree"]["num"]=None
            if str(Final_value_village) in ["0123456"] and str(Final_value_idle) in ["01234567"]:
                if str(Final_value_village) in ["012"]:
                    print("莊家補牌")
                    Color , number = self.Choose_playing_cards()
                    playing_cards=str(Color)+str(number)
                    playing_cards_num = int(str(self.Control[number]))
                    print(playing_cards)
                    self.data["Baccarat"][GroupId]["village"]["Handthree"]={}
                    self.data["Baccarat"][GroupId]["village"]["Handthree"]["Card"]=playing_cards
                    self.data["Baccarat"][GroupId]["village"]["Handthree"]["num"]=number
                    self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]=playing_cards_num
                    Final_value_village+=self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]
                    if Final_value_village >= 10:Final_value_village-=10
                    self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]=Final_value_village
                    if idleOutsourcing == True:
                        loc=self.data["Baccarat"][GroupId]
                        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})({loc["idle"]["Handthree"]["Card"]})「{Final_value_idle}」')
                    else:
                        loc=self.data["Baccarat"][GroupId]
                        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})「{Final_value_idle}」')
                elif str(Final_value_village) in ["3"]:
                    if idleOutsourcing == True and self.data["Baccarat"][GroupId]["idle"]["Handthree"]["num"] == 8:pass
                    else:
                        print("莊家補牌")
                        Color , number = self.Choose_playing_cards()
                        playing_cards=str(Color)+str(number)
                        playing_cards_num = int(str(self.Control[number]))
                        print(playing_cards)
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]={}
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["Card"]=playing_cards
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["num"]=number
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]=playing_cards_num
                        Final_value_village+=self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]
                        if Final_value_village >= 10:Final_value_village-=10
                        self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]=Final_value_village
                        if idleOutsourcing == True:
                            loc=self.data["Baccarat"][GroupId]
                            self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})({loc["idle"]["Handthree"]["Card"]})「{Final_value_idle}」')
                        else:
                            loc=self.data["Baccarat"][GroupId]
                            self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})「{Final_value_idle}」')
                elif str(Final_value_village) in ["4"]:
                    if idleOutsourcing == True and self.data["Baccarat"][GroupId]["idle"]["Handthree"]["num"] in ["0","1","8","9"]:pass
                    else:
                        print("莊家補牌")
                        Color , number = self.Choose_playing_cards()
                        playing_cards=str(Color)+str(number)
                        playing_cards_num = int(str(self.Control[number]))
                        print(playing_cards)
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]={}
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["Card"]=playing_cards
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["num"]=number
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]=playing_cards_num
                        Final_value_village+=self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]
                        if Final_value_village >= 10:Final_value_village-=10
                        self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]=Final_value_village
                        if idleOutsourcing == True:
                            loc=self.data["Baccarat"][GroupId]
                            self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})({loc["idle"]["Handthree"]["Card"]})「{Final_value_idle}」')
                        else:
                            loc=self.data["Baccarat"][GroupId]
                            self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})「{Final_value_idle}」')
                elif str(Final_value_village) in ["5"]:
                    if idleOutsourcing == True and self.data["Baccarat"][GroupId]["idle"]["Handthree"]["num"] in ["0","1","2","3","8","9"]:pass
                    else:
                        print("莊家補牌")
                        Color , number = self.Choose_playing_cards()
                        playing_cards=str(Color)+str(number)
                        playing_cards_num = int(str(self.Control[number]))
                        print(playing_cards)
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]={}
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["Card"]=playing_cards
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["num"]=number
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]=playing_cards_num
                        Final_value_village+=self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]
                        if Final_value_village >= 10:Final_value_village-=10
                        self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]=Final_value_village
                        if idleOutsourcing == True:
                            loc=self.data["Baccarat"][GroupId]
                            self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})({loc["idle"]["Handthree"]["Card"]})「{Final_value_idle}」')
                        else:
                            loc=self.data["Baccarat"][GroupId]
                            self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})「{Final_value_idle}」')
                elif str(Final_value_village) in ["6"]:
                    if idleOutsourcing == True and self.data["Baccarat"][GroupId]["idle"]["Handthree"]["num"] in ["6","7"]:
                        print("莊家補牌")
                        Color , number = self.Choose_playing_cards()
                        playing_cards=str(Color)+str(number)
                        playing_cards_num = int(str(self.Control[number]))
                        print(playing_cards)
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]={}
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["Card"]=playing_cards
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["num"]=number
                        self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]=playing_cards_num
                        Final_value_village+=self.data["Baccarat"][GroupId]["village"]["Handthree"]["value"]
                        if Final_value_village >= 10:Final_value_village-=10
                        self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]=Final_value_village
                        loc=self.data["Baccarat"][GroupId]
                        self.data["Baccarat"][GroupId]["send"].append(f'\n莊|({loc["village"]["Handone"]["Card"]})({loc["village"]["Handtwo"]["Card"]})({loc["village"]["Handthree"]["Card"]})「{Final_value_village}」\n閒|({loc["idle"]["Handone"]["Card"]})({loc["idle"]["Handtwo"]["Card"]})({loc["idle"]["Handthree"]["Card"]})「{Final_value_idle}」')
        time.sleep(0.1)
        self.data["Baccarat"][GroupId]["judge"]={
            'Tie':False,
            'Bank':False,
            'Play':False,
            'Lucky':False,
            'BankPair':False,
            'PlayPair':False
        }
        if self.data["Baccarat"][GroupId]["Win_or_lose"]["village"] == self.data["Baccarat"][GroupId]["Win_or_lose"]["idle"]:
            LineNotifysend = "\n和局"
            self.data["Baccarat"][GroupId]["judge"]["Tie"]=True
            if self.data["Baccarat"][GroupId]["village"]["Handone"]["num"] == self.data["Baccarat"][GroupId]["village"]["Handtwo"]["num"]:
                LineNotifysend+="\n莊對"
                self.data["Baccarat"][GroupId]["judge"]["BankPair"]=True
            if self.data["Baccarat"][GroupId]["idle"]["Handone"]["num"] == self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["num"]:
                LineNotifysend+="\n閒對"
                self.data["Baccarat"][GroupId]["judge"]["PlayPair"]=True
            self.data["Baccarat"][GroupId]["send"].append(LineNotifysend)
            print(LineNotifysend)
            self.client.sendMessage('c2d5bef799adbcec049ec02562066fb2c',"\n"+str(self.client.getGroup(GroupId).name)+"\n\n第"+str(self.data["Board"])+"局"+LineNotifysend)
        elif self.data["Baccarat"][GroupId]["Win_or_lose"]["village"] > self.data["Baccarat"][GroupId]["Win_or_lose"]["idle"]:
            LineNotifysend = "\n莊贏"
            self.data["Baccarat"][GroupId]["judge"]["Bank"]=True
            if self.data["Baccarat"][GroupId]["village"]["Handone"]["num"] == self.data["Baccarat"][GroupId]["village"]["Handtwo"]["num"]:
                LineNotifysend+="\n莊對"
                self.data["Baccarat"][GroupId]["judge"]["BankPair"]=True
            if self.data["Baccarat"][GroupId]["idle"]["Handone"]["num"] == self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["num"]:
                LineNotifysend+="\n閒對"
                self.data["Baccarat"][GroupId]["judge"]["PlayPair"]=True
            if str(self.data["Baccarat"][GroupId]["Win_or_lose"]["village"]) == "6":
                LineNotifysend+="\n幸運6"
                self.data["Baccarat"][GroupId]["judge"]["Lucky"]=True
            self.data["Baccarat"][GroupId]["send"].append(LineNotifysend)
            print(LineNotifysend)
            #self.client.sendMessage('c2d5bef799adbcec049ec02562066fb2c',"\n"+str(self.client.getGroup(GroupId).name)+"\n\n第"+str(self.data["Board"])+"局"+LineNotifysend)
        else:
            LineNotifysend = "\n閒贏"
            self.data["Baccarat"][GroupId]["judge"]["Play"]=True
            if self.data["Baccarat"][GroupId]["village"]["Handone"]["num"] == self.data["Baccarat"][GroupId]["village"]["Handtwo"]["num"]:
                LineNotifysend+="\n莊對"
                self.data["Baccarat"][GroupId]["judge"]["BankPair"]=True
            if self.data["Baccarat"][GroupId]["idle"]["Handone"]["num"] == self.data["Baccarat"][GroupId]["idle"]["Handtwo"]["num"]:
                LineNotifysend+="\n閒對"
                self.data["Baccarat"][GroupId]["judge"]["PlayPair"]=True
            self.data["Baccarat"][GroupId]["send"].append(LineNotifysend)
            print(LineNotifysend)
            #self.client.sendMessage('c2d5bef799adbcec049ec02562066fb2c',"\n"+str(self.client.getGroup(GroupId).name)+"\n\n第"+str(self.data["Board"])+"局"+LineNotifysend)
        #self.client.sendMessage(GroupId,"\n將於10秒後開始遊戲\n(公告有提示秒數)")
        #self.client.sendMessage(GroupId,"\n將於3秒後開始遊戲")
        time.sleep(1)
        #self.client.sendMessage(GroupId,"\n將於2秒後開始遊戲")
        time.sleep(1)
        #self.client.sendMessage(GroupId,"\n將於1秒後開始遊戲")
        time.sleep(1)
        self.client.sendMessage(GroupId,"第"+str(self.data["Board"])+"局遊戲開始")
        #self.client.sendMessage(GroupId,"\n下注時間剩餘35秒\n(公告有提示秒數)")
        time.sleep(0.1)
        self.data["Baccarat"][GroupId]["Game_stage"]="Bet time"
        if "Place_a_bet" not in self.data["Baccarat"][GroupId]:self.data["Baccarat"][GroupId]["Place_a_bet"]={}
        if "Bank" not in self.data["Baccarat"][GroupId]["Place_a_bet"]:self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]={}#莊
        if "Play" not in self.data["Baccarat"][GroupId]["Place_a_bet"]:self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]={}#閒
        if "BankPair" not in self.data["Baccarat"][GroupId]["Place_a_bet"]:self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]={}#莊對
        if "PlayPair" not in self.data["Baccarat"][GroupId]["Place_a_bet"]:self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]={}#閒對
        if "Tie" not in self.data["Baccarat"][GroupId]["Place_a_bet"]:self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]={}#和
        if "Lucky" not in self.data["Baccarat"][GroupId]["Place_a_bet"]:self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]={}#幸運6
        self.data["Baccarat"][GroupId]["gameover"]=True
        time.sleep(0.1)
        self.client.sendMessage(GroupId,"==========下注區==========")
        #self.client.sendMessage(GroupId,"\n下注時間剩餘10秒")
        time.sleep(7)
        #self.client.sendMessage(GroupId,"\n下注時間剩餘3秒")
        time.sleep(1)
        #self.client.sendMessage(GroupId,"\n下注時間剩餘2秒")
        time.sleep(1)
        #self.client.sendMessage(GroupId,"\n下注時間剩餘1秒")
        time.sleep(1)
        self.client.sendMessage(GroupId,"==========停止下注==========")
        self.data["Baccarat"][GroupId]["Game_stage"]="Draw"
        a1=0#莊
        a2=0#閒
        a3=0#和
        a4=0#莊對
        a5=0#閒對
        a6=0#總和
        a7=0#幸運6
        qqqqq=""
        self.client.sendMessage(GroupId,"開始統計該局下注...")
        ret_ ="—————牌局資訊—————\n"
        ret_+="局數："+str(self.data["Board"])+"\n"
        ret_+="—————有效下注—————"
        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
            try:
                fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][mi_d]
                ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊 | "+str(fffrr)
                time.sleep(0.1)
                a1+=fffrr
            except Exception as e:print(e)
        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]:
            try:
                fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][mi_d]
                ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒 | "+str(fffrr)
                time.sleep(0.1)
                a2+=fffrr
            except Exception as e:print(e)
        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]:
            try:
                fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][mi_d]
                ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊對 | "+str(fffrr)
                time.sleep(0.1)
                a3+=fffrr
            except Exception as e:print(e)
        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]:
            try:
                fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][mi_d]
                ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒對 | "+str(fffrr)
                time.sleep(0.1)
                a4+=fffrr
            except Exception as e:print(e)
        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]:
            try:
                fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][mi_d]
                ret_+="\n"+self.client.getContact(mi_d).displayName+"=>和 | "+str(fffrr)
                time.sleep(0.1)
                a5+=fffrr
            except Exception as e:print(e)
        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
            try:
                fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][mi_d]
                ret_+="\n"+self.client.getContact(mi_d).displayName+"=>幸運6 | "+str(fffrr)
                time.sleep(0.1)
                a7+=fffrr
            except Exception as e:print(e)
        ret_+="\n—————下注總表—————"
        ret_+=f"\n莊 | {a1}元"
        ret_+=f"\n閒 | {a2}元"
        ret_+=f"\n莊對 | {a3}元"
        ret_+=f"\n閒對 | {a4}元"
        ret_+=f"\n和 | {a5}元"
        ret_+=f"\n幸運6 | {a7}元"
        a6=a1+a2+a3+a4+a5+a7
        ret_+=f"\n\n下注總和：{a6}元"
        self.client.sendMessage(GroupId,ret_)
        time.sleep(0.1)
        #Set_up_announcement(GroupId,"目前狀態：等待開牌")
        time.sleep(0.1)
        if self.data["Baccarat"][GroupId]["gameover"] == True:
            self.client.sendMessage(GroupId,"\n此局無人下注\n遊戲已中止\n如想繼續遊戲\n請輸入「開始遊戲」")
            del self.data["Baccarat"][GroupId]
        else:
            self.client.sendMessage(GroupId,"統計完畢\n等待開牌結果....")
            time.sleep(2)
            for x in self.data["Baccarat"][GroupId]["send"]:time.sleep(2);self.client.sendMessage(GroupId,f"開牌結果{x}")
            #Set_up_announcement(GroupId,"目前狀態：結算中")
            self.client.sendMessage(GroupId,"系統結算中....")
            ret_="結算系統"
            b1=0
            if self.data["Baccarat"][GroupId]["judge"]["Bank"] == True or self.data["Baccarat"][GroupId]["judge"]["Tie"] == True:
                if self.data["Baccarat"][GroupId]["judge"]["Tie"] == True:
                    for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
                        fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][mi_d]
                        ret_+="\n"+self.client.getContact(mi_d).displayName+"=>幸運6 | "+str(fffrr*-1)
                        time.sleep(0.1)
                        b1+=int(fffrr)
                    for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
                        fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][mi_d]
                        self.data["money"][mi_d]+=int(fffrr)
                        ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊 | "+str(fffrr)
                        time.sleep(0.1)
                        b1+=int(fffrr)
                else:
                    if self.data["Baccarat"][GroupId]["judge"]["Lucky"] == True:
                        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
                            fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][mi_d]
                            self.data["money"][mi_d]+=int(fffrr*12)
                            ret_+="\n"+self.client.getContact(mi_d).displayName+"=>幸運6 | "+str(fffrr*12)
                            time.sleep(0.1)
                            b1+=int(fffrr*12*-1)
                        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
                            fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][mi_d]
                            self.data["money"][mi_d]+=int(fffrr*0.5)
                            ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊 | "+str(fffrr*0.5)
                            time.sleep(0.1)
                            b1+=int(fffrr*0.5*-1)
                    else:
                        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
                            fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][mi_d]
                            ret_+="\n"+self.client.getContact(mi_d).displayName+"=>幸運6 | "+str(fffrr*-1)
                            time.sleep(0.1)
                            b1+=int(fffrr)
                        for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
                            fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][mi_d]
                            self.data["money"][mi_d]+=int(fffrr*2)
                            ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊 | "+str(fffrr*2)
                            time.sleep(0.1)
                            b1+=int(fffrr*2*-1)
            else:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][mi_d]
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊 | "+str(fffrr*-1)
                    time.sleep(0.1)
                    b1+=int(fffrr)
            if self.data["Baccarat"][GroupId]["judge"]["Lucky"] == True and self.data["Baccarat"][GroupId]["judge"]["Bank"] == False:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][mi_d]
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>幸運6 | "+str(fffrr*-1)
                    time.sleep(0.1)
                    b1+=int(fffrr)
            if self.data["Baccarat"][GroupId]["judge"]["Play"] == True or self.data["Baccarat"][GroupId]["judge"]["Tie"] == True:
                if self.data["Baccarat"][GroupId]["judge"]["Tie"] == True:
                    for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]:
                        fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][mi_d]
                        self.data["money"][mi_d]+=int(fffrr)
                        ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒 | "+str(fffrr)
                        time.sleep(0.1)
                        b1+=int(fffrr)
                else:
                    for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]:
                        fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][mi_d]
                        self.data["money"][mi_d]+=int(fffrr*2)
                        ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒 | "+str(fffrr*2)
                        time.sleep(0.1)
                        b1+=int(fffrr*2*-1)
            else:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][mi_d]
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒 | "+str(fffrr*-1)
                    time.sleep(0.1)
                    b1+=int(fffrr)
            if self.data["Baccarat"][GroupId]["judge"]["BankPair"] == True:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][mi_d]
                    self.data["money"][mi_d]+=int(fffrr*11)
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊對 | "+str(fffrr*11)
                    time.sleep(0.1)
                    b1+=int(fffrr*11*-1)
            else:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][mi_d]
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>莊對 | "+str(fffrr*-1)
                    time.sleep(0.1)
                    b1+=int(fffrr)
            if self.data["Baccarat"][GroupId]["judge"]["PlayPair"] == True:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][mi_d]
                    self.data["money"][mi_d]+=int(fffrr*11)
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒對 | "+str(fffrr*11)
                    time.sleep(0.1)
                    b1+=int(fffrr*11*-1)
            else:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][mi_d]
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>閒對 | "+str(fffrr*-1)
                    time.sleep(0.1)
                    b1+=int(fffrr)
            if self.data["Baccarat"][GroupId]["judge"]["Tie"] == True:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][mi_d]
                    self.data["money"][mi_d]+=int(fffrr*8)
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>和 | "+str(fffrr*8)
                    time.sleep(0.1)
                    b1+=int(fffrr*8*-1)
            else:
                for mi_d in self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]:
                    fffrr=self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][mi_d]
                    ret_+="\n"+self.client.getContact(mi_d).displayName+"=>和 | "+str(fffrr*-1)
                    time.sleep(0.1)
                    b1+=int(fffrr)
            if b1 < 0:ret_+="\n\n電腦賠"+str(b1)
            else:ret_+="\n\n電腦賺"+str(b1)
            #self.client.sendMessage(GroupId,ret_)
            time.sleep(0.1)
            self.client.sendMessage(GroupId,"第"+str(self.data["Board"])+"局遊戲結束")
            time.sleep(2)
            self.data["Baccarat"][GroupId] = {}
            self.save_data()
            self.calculate_game(GroupId)
    def add_bet(self,GroupId,Player,Money,Type):
        #typelist
        #3=三寶
        #2=luck
        #1=和
        #4=莊
        #5=閒對
        #6=閒
        #7=莊對
        #8=Cancel
        if Type==8:
            bal = 0
            try:
                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
                    bal+=self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player]
                    del self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player]
                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]:
                    bal+=self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player]
                    del self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player]
                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]:
                    bal+=self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]
                    del self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]
                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
                    bal+=self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player]
                    del self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player]
                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]:
                    bal+=self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]
                    del self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]
                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]:
                    bal+=self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]
                    del self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]
                self.data["money"][Player]+=bal
                print(bal)
                self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功取消全部下注\n歸還："+str(bal)+"元"+"\n剩餘："+str(self.data["money"][Player])+"元")
            except Exception as e:print(e)
        if Type==4:
            num1 = Money
            try: 
                num = int(num1) 
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元")
                            else:   
                                self.data["Baccarat"][GroupId]["gameover"]=False
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(莊)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player])+"元(原下注"+str(Original_value)+"元)\n剩餘："+str(self.data["money"][Player])+"元")       
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Bank"][Player])+"元(莊)\n剩餘："+str(self.data["money"][Player])+"元")
                                self.save_data()
            except Exception as e:pass
        if Type==7:
            num1 = Money
            try: 
                num = int(num1) 
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元")
                            else: 
                                self.data["Baccarat"][GroupId]["gameover"]=False
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(莊對)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player])+"元(原下注"+str(Original_value)+"元)\n剩餘："+str(self.data["money"][Player])+"元")       
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player])+"元(莊對)\n剩餘："+str(self.data["money"][Player])+"元") 
                                self.save_data()
            except Exception as e:pass
        if Type==6:
            num1 = Money
            try: 
                num = int(num1) 
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元") 
                            else: 
                                self.data["Baccarat"][GroupId]["gameover"]=False
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(閒)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player])+"元(原下注"+str(Original_value)+"元)\n剩餘："+str(self.data["money"][Player])+"元")       
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Play"][Player])+"元(閒)\n剩餘："+str(self.data["money"][Player])+"元") 
                                self.save_data()
            except Exception as e:pass
        if Type==5:
            num1 = Money
            try: 
                num = int(num1) 
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元")
                            else: 
                                self.data["Baccarat"][GroupId]["gameover"]=False
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(閒對)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player])+"元(原下注"+str(Original_value)+"元)\n剩餘："+str(self.data["money"][Player])+"元")       
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player])+"元(閒對)\n剩餘："+str(self.data["money"][Player])+"元") 
                                self.save_data()
            except Exception as e:pass
        if Type==1:
            num1 = Money
            try: 
                num = int(num1) 
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元")
                            else: 
                                self.data["Baccarat"][GroupId]["gameover"]=False
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(和)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player])+"元(原下注"+str(Original_value)+"元)\n剩餘："+str(self.data["money"][Player])+"元")       
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player])+"元(和)\n剩餘："+str(self.data["money"][Player])+"元")       
                                self.save_data()
            except Exception as e:pass
        if Type==2:
            num1 = Money
            try: 
                num = int(num1) 
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元")
                            else: 
                                self.data["Baccarat"][GroupId]["gameover"]=False 
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(幸運6)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player])+"元(原下注"+str(Original_value)+"元)\n剩餘："+str(self.data["money"][Player])+"元")       
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Lucky"][Player])+"元(幸運6)\n剩餘："+str(self.data["money"][Player])+"元")       
                                self.save_data()
            except Exception as e:pass
        if Type==3: 
            try: 
                num = Money
                if num == 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 下注金額不可為0")
                else: 
                    if num < 0:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 輸入數字不可為負數") 
                    else: 
                        if num <= 99:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 數字不可小於100") 
                        else:
                            if Player not in self.data["money"]:self.data["money"][Player]=2000
                            if num*3 > self.data["money"][Player]:self.client.sendMessage(GroupId,"\n"+self.client.getContact(Player).displayName+" | 你的餘額不足\n剩餘："+str(self.data["money"][Player])+"元")
                            else: 
                                display=""
                                self.data["Baccarat"][GroupId]["gameover"]=False
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    display+="\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(莊對)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player])+"元(原下注"+str(Original_value)+"元)\n------------------------"   
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    display+="\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["BankPair"][Player])+"元(莊對)\n------------------------" 
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    display+="\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(閒對)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player])+"元(原下注"+str(Original_value)+"元)\n------------------------"    
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    display+="\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["PlayPair"][Player])+"元(閒對)\n------------------------"
                                if Player in self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"]:
                                    Original_value = self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]+=int(num)
                                    self.data["money"][Player]-=int(num)
                                    display+="\n"+self.client.getContact(Player).displayName+" | ✅成功加注"+str(num)+"元(和)\n目前共下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player])+"元(原下注"+str(Original_value)+"元)\n\n剩餘："+str(self.data["money"][Player])+"元"
                                else:
                                    self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player]=num
                                    self.data["money"][Player]-=int(num)
                                    display+="\n"+self.client.getContact(Player).displayName+" | ✅成功下注"+str(self.data["Baccarat"][GroupId]["Place_a_bet"]["Tie"][Player])+"元(和)\n\n剩餘："+str(self.data["money"][Player])+"元"     
                                self.client.sendMessage(GroupId,display) 
                                self.save_data()
            except Exception as e:pass
    def wait_for_bet(self,GroupId):
        if GroupId in self.data['running']:
            self.data['running'][GroupId]['bet_time']=True
            self.client.sendMessage(GroupId,'=== 請下注(30秒限制) ===')
            time.sleep(30)
            self.data['running'][GroupId]['bet_time']=False
            self.client.sendMessage(GroupId,'=== 停止下注 ===')
            if self.data['running'][GroupId]['players']=={}:
                self.client.sendMessage(GroupId,'此群無人下注\n已自動結束遊戲')
                del self.data['running'][GroupId]
                return 
            return self.calculate_game(GroupId)
    def register_user(self,GroupId,User,Name=None):
        if User not in self.userdata:
            if not Name:Name='不明'
            self.userdata[User]={'Money':1000,'Name':Name,'Level':'user'}
            self.client.sendMessage(GroupId,'註冊成功!\n餘額:1000')
            self.save_data()
        else:
            self.client.sendMessage(GroupId,'註冊失敗!\n已經註冊過了')
    def save_data(self):
        #備份檔案
        json.dump(self.data,codecs.open('expansion/data/hand_group.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        json.dump(self.userdata,codecs.open('expansion/data/userdata.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        return True
    def Check_Money(self,GroupId,User):
        if User in self.userdata:
            lev='未知身分'
            if self.userdata[User]['Level']=='admin':
                lev='管理員'
            if self.userdata[User]['Level']=='user':
                lev='平民'
            self.client.sendMessage(GroupId,f"名稱:{self.userdata[User]['Name']}\n餘額:{self.userdata[User]['Money']}\n階級:{lev}")
        else:
            self.client(GroupId,'您尚未註冊帳戶\n請輸入`註冊`')