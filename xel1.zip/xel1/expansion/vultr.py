import requests
class vultrAPI:
    def __init__(self):
        self.url='https://api.vultr.com/v2/'
        self.request=requests.session()
        self.key='UWSP2J7UQXBHKSXKAWWHYIWDHR72AB5QUQRQ'
        self.request.headers.update({'Authorization':f'Bearer {self.key}'})
    def check_error(self,code):
        code=int(code)
        if code !=200:
            if code==201:return'Your request was accepted. The resource was created.'
            elif code==202:return'Your request was accepted. The resource was created or updated.'
            elif code==204:return'Your request succeeded, there is no additional information returned.'
            elif code==400:return'Your request was malformed.'
            elif code==401:return'You did not supply valid authentication credentials.'
            elif code==403:return'You are not allowed to perform that action.'
            elif code==404:return'No results were found for your request.'
            elif code==429:return'Your request exceeded the API rate limit.'
            elif code==500:return'We were unable to perform the request due to server-side problems.'
            else:return f'Error For No Reason.\nCode:{code}'
        else:return'Success'
    def Account_Info(self):
        req=self.request.get()