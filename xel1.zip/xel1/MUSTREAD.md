*Remember to edit all mid and gid that include the bbot file*
also edit the text file