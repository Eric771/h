# -*- coding: utf-8 -*-
from thrift.transport import THttpClient
from thrift.protocol import TCompactProtocol
from .SecondaryQrCodeLogin import *
from .SecondaryQrCodeLogin.ttypes import *
import traceback, time, copy, urllib
from LINECONF import *

host = 'https://gxx.line.naver.jp'
qrEndpoint = '/acct/lgn/sq/v1'
verifierEndpoint = '/acct/lp/lgn/sq/v1'

def createSecondaryQrCodeLoginService(host, headers):
    transport = THttpClient.THttpClient(host)
    transport.setCustomHeaders(headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    client = SecondaryQrCodeLoginService.Client(protocol)
    return client

def createSecondaryQrCodeLoginPermitNoticeService(host, headers):
    transport = THttpClient.THttpClient(host)
    transport.setCustomHeaders(headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    client = SecondaryQrCodeLoginPermitNoticeService.Client(protocol)
    return client
            
class LineAuth(object):
  
    def __init__(self, Helper=None, Groups = None):
        self.Helper = Helper
        self.Groups = Groups
        
    def generateAuthToken(self,MIDuser=None):
      url = host+qrEndpoint
      headers = line_config_random("DESKTOPMAC")
      headers["x-lal"] = 'en_id'

      client = createSecondaryQrCodeLoginService(url, headers)
      session = client.createSession(CreateQrSessionRequest())
      session_id = session.authSessionId
      print ('Session :', session)
      
      qrcode = client.createQrCode(CreateQrCodeRequest(session_id))
      self.Helper.sendImageWithURL(self.Groups, "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data="+urllib.parse.quote(qrcode.callbackUrl))
      self.Helper.sendMessage(self.Groups,"Click Link To Login\n\n{}".format(qrcode.callbackUrl))

      url = host+verifierEndpoint
      h2 = copy.deepcopy(headers)
      h2['X-Line-Access'] = session_id

      client_verif = createSecondaryQrCodeLoginPermitNoticeService(url, h2)
      qrverified = client_verif.checkQrCodeVerified(CheckQrCodeVerifiedRequest(session_id))
      certificate = ""
      try:
       try:
        with open('certificate/' + MIDuser + '.crt', 'r') as f:
          certificate = f.read()
          certverified = client.verifyCertificate(VerifyCertificateRequest(session.authSessionId, certificate))
          print ('Certificate Verified :', certverified)
       except:
          client.verifyCertificate(VerifyCertificateRequest(session.authSessionId, None))
          return
      except SecondaryQrCodeException as error:
        print ('Error Verify Certificate :', error)
        pincode = client.createPinCode(CreatePinCodeRequest(session.authSessionId))
        self.Helper.sendMessage(self.Groups,"Pin code : {}".format(pincode.pinCode))
        pincodeverified = client_verif.checkPinCodeVerified(CheckPinCodeVerifiedRequest(session.authSessionId))
        print ('Pin Code Verified :', pincodeverified)
      except Exception:
        traceback.print_exc()
      qrcodelogin = client.qrCodeLogin(QrCodeLoginRequest(session.authSessionId, 'VH-PC', True))
      print ('Qr Code Login :', qrcodelogin)
      with open('certificate/' + MIDuser + '.crt', 'w') as f:
         f.write(qrcodelogin.certificate)
      return qrcodelogin.accessToken